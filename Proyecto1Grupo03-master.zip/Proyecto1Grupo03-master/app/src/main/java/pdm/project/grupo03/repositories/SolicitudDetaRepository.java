package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Solicitud;
import pdm.project.grupo03.models.SolicitudDeta;
import pdm.project.grupo03.models.Usuario;

public class SolicitudDetaRepository {

    private static final String TABLA = "solicituddeta";

    public static void guardar(SolicitudDeta solicitudDeta){
        ContentValues cv = new ContentValues();
        cv.put("idsolicitud", solicitudDeta.getIdsolicitud());
        cv.put("idpropuesta", solicitudDeta.getIdpropuesta());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<SolicitudDeta> consultar(String condiciones, String[] argumentos){
        List<SolicitudDeta> detalleSolicitudes = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return detalleSolicitudes;
        }
        while(!cursor.isAfterLast()){
            SolicitudDeta detalle = new SolicitudDeta();
            detalle.setIdsolicitud(cursor.getInt(0));
            detalle.setIdpropuesta(cursor.getInt(1));
            detalleSolicitudes.add(detalle);
            cursor.moveToNext();
        }
        cursor.close();
        return detalleSolicitudes;
    }

    public static void eliminar(int idsolicitud, int idpropuesta){
        SolicitudDeta detalle = consultar("idsolicitud = ? AND idpropuesta = ?", new String[]{ String.valueOf(idsolicitud), String.valueOf(idpropuesta) }).get(0);
        if(Objects.nonNull(detalle)){
            DatabaseController.sqLiteDatabase.delete(TABLA, "idsolicitud = ? AND idpropuesta = ?", new String[]{ String.valueOf(idsolicitud), String.valueOf(idpropuesta) });
        }
    }

}
