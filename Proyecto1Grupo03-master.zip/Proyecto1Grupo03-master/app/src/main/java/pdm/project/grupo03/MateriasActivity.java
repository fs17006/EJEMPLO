package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.adapters.ListViewAdapter;
import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.enums.ENUMS;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.routing.Rutas;

public class MateriasActivity extends AppCompatActivity {

    ListView listView;
    Button btnAgregar;
    ArrayList<Materia> items = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materias);
        DatabaseOperations.abrirConexion();
        items.addAll(MateriaRepository.consultar(null, null).stream().sorted(Comparator.comparing(Materia::getNombre)).collect(Collectors.toList()));
        DatabaseOperations.cerrarConexion();
        btnAgregar = findViewById(R.id.btn_add_materia);
        btnAgregar.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.VISIBLE : View.INVISIBLE);
        listView = findViewById(R.id.listView_usuarios);
        listView.setAdapter(new ListViewAdapter<>(this, R.layout.materias_list_item, items, ENUMS.TABLAS.MATERIA));
        listView.setOnItemClickListener((adapterView, view, i, l) -> editarMateria(items.get(i)));
    }

    public void editarMateria(Materia materia){
        try{
            Intent intent = new Intent(this, Rutas.getClase("MateriasEditarActivity"))
                    .putExtra("materia", materia);
            this.startActivity(intent);
            this.finish();
        }catch (ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }

    public void agregarMateria(View view){
        try{
            Intent intent = new Intent(this, Rutas.getClase("MateriasAgregarActivity"));
            this.startActivity(intent);
            this.finish();
        }catch (ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }
}