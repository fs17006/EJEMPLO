package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Ciclo;
import pdm.project.grupo03.models.Dia;
import pdm.project.grupo03.models.Horario;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Propuesta;
import pdm.project.grupo03.models.TipoActividad;
import pdm.project.grupo03.repositories.CicloRepository;
import pdm.project.grupo03.repositories.DiaRepository;
import pdm.project.grupo03.repositories.HorarioRepository;
import pdm.project.grupo03.repositories.LocalRepository;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.PropuestaRepository;
import pdm.project.grupo03.repositories.TipoActividadRepository;
import pdm.project.grupo03.routing.Rutas;

public class PropuestasAgregarActivity extends AppCompatActivity {

    TextView txtCicloActual;
    Spinner spnMateria;
    Spinner spnTipoActividad;
    Spinner spnLocal;
    Spinner spnHorario;
    Spinner spnDia;
    EditText editGrupo;
    List<Materia> materias;
    List<TipoActividad> tipoActividades;
    Ciclo ciclo;
    List<Local> locales;
    List<Dia> dias;
    List<Horario> horarios;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_propuestas_agregar);
        initPantalla();
    }

    private void initPantalla(){
        txtCicloActual = findViewById(R.id.txt_ciclo_actual_add_propuesta);
        spnMateria = findViewById(R.id.spn_materia_add_propuesta);
        spnTipoActividad = findViewById(R.id.spn_tipo_actividad_add_propuesta);
        spnLocal = findViewById(R.id.spn_local_add_propuesta);
        spnHorario = findViewById(R.id.spn_horario_add_propuesta);
        spnDia = findViewById(R.id.spn_dia_add_propuesta);
        editGrupo = findViewById(R.id.edit_grupo_add_propuesta);
        DatabaseOperations.abrirConexion();
        List<Profesor> profesores = ProfesorRepository.consultar("user = ?", new String[]{ Utils.loggedUser.getUser() });
        Profesor profesor = null;
        if(!profesores.isEmpty()){
            profesor = profesores.get(0);
        }
        assert profesor != null;
        materias = MateriaRepository.consultar("coordinador = ?", new String[]{ profesor.getIdprofesor() });
        ciclo = CicloRepository.consultarCicloActual();
        locales = LocalRepository.consultar(null, null);
        dias = DiaRepository.consultar(null, null);
        horarios = HorarioRepository.consultar(null, null);
        tipoActividades = TipoActividadRepository.consultar(null, null);

        DatabaseOperations.cerrarConexion();
        spnMateria.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, materias.stream().map(Materia::getNombre).collect(Collectors.toList())));
        spnLocal.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, locales.stream().map(Local::getIdlocal).collect(Collectors.toList())));
        spnDia.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, dias.stream().map(Dia::getDia).collect(Collectors.toList())));
        spnHorario.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, horarios.stream().map(Horario::getHorario).collect(Collectors.toList())));
        spnTipoActividad.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tipoActividades.stream().map(TipoActividad::getTipoActividad).collect(Collectors.toList())));
        txtCicloActual.setText(ciclo.getIdciclo());
    }

    public void guardarNuevaPropuesta(View view) throws ClassNotFoundException {
        if(TextUtils.isEmpty(editGrupo.getText())){
            Toast.makeText(this, "El grupo no puede estar vacio", Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseOperations.abrirConexion();
        Propuesta propuesta = new Propuesta();
        propuesta.setCodmateria(materias.stream().filter(m -> m.getNombre().equals(spnMateria.getSelectedItem())).collect(Collectors.toList()).get(0).getCodmateria());
        propuesta.setGrupo(Integer.parseInt(editGrupo.getText().toString()));
        propuesta.setIddia(dias.stream().filter(d -> d.getDia().equals(spnDia.getSelectedItem())).collect(Collectors.toList()).get(0).getIddia());
        propuesta.setIdciclo(ciclo.getIdciclo());
        propuesta.setIdestado(1);
        propuesta.setIdhora(horarios.stream().filter(h -> h.getHorario().equals(spnHorario.getSelectedItem())).collect(Collectors.toList()).get(0).getIdhorario());
        propuesta.setUser(Utils.loggedUser.getUser());
        propuesta.setIdlocal(locales.stream().filter(l -> l.getIdlocal().equals(spnLocal.getSelectedItem())).collect(Collectors.toList()).get(0).getIdlocal());
        propuesta.setIdpropuesta(PropuestaRepository.consultar(null, null).isEmpty() ? 1 : PropuestaRepository.consultar(null, null).size() + 1);
        propuesta.setIdtipoactividad(tipoActividades.stream().filter(ta -> ta.getTipoActividad().equals(spnTipoActividad.getSelectedItem())).collect(Collectors.toList()).get(0).getIdTipoActividad());
        PropuestaRepository.guardar(propuesta);
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("PropuestasActivity")));
        this.finish();
    }

    @Override
    public void onBackPressed() {
        try {
            this.startActivity(new Intent(this, Rutas.getClase("PropuestasActivity")));
            this.finish();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

}