package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Horario;
import pdm.project.grupo03.models.Local;

public class HorarioRepository {

    private static final String TABLA = "horario";

    public static void guardar(Horario horario){
        ContentValues cv = new ContentValues();
        cv.put("idhora", horario.getIdhorario());
        cv.put("hora", horario.getHorario());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Horario> consultar(String condiciones, String[] argumentos){
        List<Horario> horarios = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return horarios;
        }
        while(!cursor.isAfterLast()){
            Horario horario = new Horario();
            horario.setIdhorario(cursor.getInt(0));
            horario.setHorario(cursor.getString(1));
            horarios.add(horario);
            cursor.moveToNext();
        }
        cursor.close();
        return horarios;
    }

}
