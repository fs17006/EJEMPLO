package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;

import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.UsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class LoginActivity extends AppCompatActivity {

    EditText user;
    EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        user = findViewById(R.id.login_user);
        pass = findViewById(R.id.login_password);
    }

    public void iniciarSesion(View view) {
        try{
            if(TextUtils.isEmpty(user.getText())){
                Toast.makeText(this, "El usuario está vacío", Toast.LENGTH_SHORT).show();
                return;
            }
            if(TextUtils.isEmpty(pass.getText())){
                Toast.makeText(this, "La contraseña está vacía", Toast.LENGTH_SHORT).show();
                return;
            }
            DatabaseOperations.abrirConexion();
            Usuario usuario = UsuarioRepository.consultar(user.getText().toString());
            DatabaseOperations.cerrarConexion();
            if(Objects.isNull(usuario)){
                Toast.makeText(this, "El usuario " + user.getText().toString() + " no existe", Toast.LENGTH_SHORT).show();
                return;
            }
            if(!Objects.equals(usuario.getPass(), pass.getText().toString())){
                Toast.makeText(this, "La contraseña no es correcta", Toast.LENGTH_SHORT).show();
                return;
            }
            Utils.loggedUser = usuario;
            Toast.makeText(this, "Bienvenido", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, Rutas.getClase("MenuPrincipalActivity"));
            this.startActivity(intent);
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "Ha ocurrido un error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}