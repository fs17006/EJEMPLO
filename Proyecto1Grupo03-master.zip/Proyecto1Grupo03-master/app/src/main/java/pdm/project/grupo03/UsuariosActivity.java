package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Objects;

import pdm.project.grupo03.adapters.ListViewAdapter;
import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.enums.ENUMS;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.UsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class UsuariosActivity extends AppCompatActivity {

    ListView listView;
    Button btnAddUser;
    ArrayList<Usuario> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mantenimiento_consultar);
        DatabaseOperations.abrirConexion();
        items.addAll(UsuarioRepository.consultar(null, null));
        DatabaseOperations.cerrarConexion();
        listView = findViewById(R.id.listView_usuarios);
        listView.setAdapter(new ListViewAdapter<>(this, R.layout.users_list_item, items, ENUMS.TABLAS.USUARIO));
        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            if(Objects.equals(Utils.loggedUser.getTipoUser(), 1)){
                editarUsuario(items.get(i));
            }
        });
        btnAddUser = findViewById(R.id.btn_add_user);
        btnAddUser.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.VISIBLE : View.INVISIBLE);
    }

    public void agregarNuevoUsuario(View view){
        try{
            Intent intent = new Intent(this, Rutas.getClase("UsuarioAgregarActivity"));
            this.startActivity(intent);
            this.finish();
        }catch (ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }

    private void editarUsuario(Usuario usuario){
        try{
            Intent intent = new Intent(this, Rutas.getClase("UsuarioEditarActivity"))
                    .putExtra("usuario", usuario);
            this.startActivity(intent);
            this.finish();
        }catch (ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }
}
