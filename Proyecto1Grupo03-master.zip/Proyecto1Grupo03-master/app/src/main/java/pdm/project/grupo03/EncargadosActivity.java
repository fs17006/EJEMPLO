package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.adapters.ListViewAdapter;
import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.enums.ENUMS;
import pdm.project.grupo03.models.Cargo;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.repositories.CargoRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.routing.Rutas;

public class EncargadosActivity extends AppCompatActivity {

    EditText editBuscar;
    ListView listViewEncargados;
    Button btnAddProfesor;
    Spinner spnCargos;
    List<Cargo> cargos;
    ArrayList<Profesor> encargados = new ArrayList<>();
    ArrayList<Profesor> encargadosFiltered = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encargados);
        DatabaseOperations.abrirConexion();
        cargos = CargoRepository.consultar(null, null);
        encargados.addAll(ProfesorRepository.consultar("idcargo = ?", new String[]{ String.valueOf(2) }));
        DatabaseOperations.cerrarConexion();
        spnCargos = findViewById(R.id.spn_cargo_profesores);
        listViewEncargados = findViewById(R.id.listView_encargados);
        btnAddProfesor = findViewById(R.id.btn_add_profesor);
        btnAddProfesor.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.VISIBLE : View.INVISIBLE);
        spnCargos.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, cargos.stream().map(Cargo::getCargo).collect(Collectors.toList())));
        spnCargos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                encargados.clear();
                encargadosFiltered.clear();
                int idCargo = cargos.stream().filter(c -> Objects.equals(c.getCargo(), spnCargos.getSelectedItem())).collect(Collectors.toList()).get(0).getIdcargo();
                DatabaseOperations.abrirConexion();
                encargados.addAll(ProfesorRepository.consultar("idcargo = ?", new String[]{ String.valueOf(idCargo) }));
                DatabaseOperations.cerrarConexion();
                encargadosFiltered.addAll(encargados);
                listViewEncargados.setAdapter(new ListViewAdapter<>(EncargadosActivity.this, R.layout.profesor_list_item, encargadosFiltered, ENUMS.TABLAS.PROFESOR));
                listViewEncargados.setOnItemClickListener((adapter, vie, j, m) -> editarEncargado(encargadosFiltered.get(j)));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        encargadosFiltered.addAll(encargados);
        editBuscar = findViewById(R.id.edit_buscar_encargados);
        editBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                encargadosFiltered.clear();
                if(editBuscar.getText().toString().isEmpty()){
                    encargadosFiltered.addAll(encargados);
                }else{
                    encargadosFiltered.addAll(encargados.stream().filter(p -> p.getNombre().toLowerCase().contains(editBuscar.getText().toString()) || p.getApellido().toLowerCase().contains(editBuscar.getText().toString()))
                            .collect(Collectors.toList()));
                }
                listViewEncargados.setAdapter(new ListViewAdapter<>(EncargadosActivity.this, R.layout.profesor_list_item, encargadosFiltered, ENUMS.TABLAS.PROFESOR));
                listViewEncargados.setOnItemClickListener((adapterView, view, pos, l) -> editarEncargado(encargadosFiltered.get(pos)));
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public void editarEncargado(Profesor profesor){
        try{
            Intent intent = new Intent(this, Rutas.getClase("EncargadosEditarActivity"))
                    .putExtra("profesor", profesor);
            this.startActivity(intent);
            this.finish();
        }catch (ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }

    public void agregarEncargado(View view){
        try{
            Intent intent = new Intent(this, Rutas.getClase("EncargadosAgregarActivity"));
            this.startActivity(intent);
            this.finish();
        }catch (ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }
}