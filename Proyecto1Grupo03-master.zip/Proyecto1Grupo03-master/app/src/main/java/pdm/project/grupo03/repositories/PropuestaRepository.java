package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Propuesta;

public class PropuestaRepository {

    private static final String TABLA = "propuesta";

    public static void guardar(Propuesta propuesta){
        ContentValues cv = new ContentValues();
        cv.put("idpropuesta", propuesta.getIdpropuesta());
        cv.put("idciclo", propuesta.getIdciclo());
        cv.put("codmateria", propuesta.getCodmateria());
        cv.put("idlocal", propuesta.getIdlocal());
        cv.put("idtipoactividad", propuesta.getIdtipoactividad());
        cv.put("iddia", propuesta.getIddia());
        cv.put("idhora", propuesta.getIdhora());
        cv.put("grupo", propuesta.getGrupo());
        cv.put("user", propuesta.getUser());
        cv.put("idestado", propuesta.getIdestado());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Propuesta> consultar(String condiciones, String[] argumentos){
        List<Propuesta> propuestas = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return propuestas;
        }
        while(!cursor.isAfterLast()){
            Propuesta propuesta = new Propuesta();
            propuesta.setIdpropuesta(cursor.getInt(0));
            propuesta.setIdciclo(cursor.getString(1));
            propuesta.setCodmateria(cursor.getString(2));
            propuesta.setIdlocal(cursor.getString(3));
            propuesta.setIdtipoactividad(cursor.getInt(4));
            propuesta.setIddia(cursor.getInt(5));
            propuesta.setIdhora(cursor.getInt(6));
            propuesta.setGrupo(cursor.getInt(7));
            propuesta.setUser(cursor.getString(8));
            propuesta.setIdestado(cursor.getInt(9));
            propuestas.add(propuesta);
            cursor.moveToNext();
        }
        cursor.close();
        return propuestas;
    }

    public static void actualizar(Propuesta propuesta){
        Propuesta prop = consultar("idpropuesta = ?", new String[]{String.valueOf(propuesta.getIdpropuesta())}).get(0);
        if(Objects.nonNull(prop)){
            ContentValues cv = new ContentValues();
            cv.put("idciclo", propuesta.getIdciclo());
            cv.put("codmateria", propuesta.getCodmateria());
            cv.put("idlocal", propuesta.getIdlocal());
            cv.put("idtipoactividad", propuesta.getIdtipoactividad());
            cv.put("iddia", propuesta.getIddia());
            cv.put("idhora", propuesta.getIdhora());
            cv.put("grupo", propuesta.getGrupo());
            cv.put("user", propuesta.getUser());
            cv.put("idestado", propuesta.getIdestado());
            DatabaseController.sqLiteDatabase.update(TABLA, cv, "idpropuesta = ?", new String[]{String.valueOf(propuesta.getIdpropuesta())});
        }
    }

    public static void eliminar(String idpropuesta){
        Propuesta propuesta = consultar("idpropuesta = ?", new String[]{ idpropuesta }).get(0);
        if(Objects.nonNull(propuesta)){
            DatabaseController.sqLiteDatabase.delete(TABLA, "idpropuesta = ?", new String[]{String.valueOf(propuesta.getIdpropuesta())});
        }
    }
}
