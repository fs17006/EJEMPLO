package pdm.project.grupo03.models;

public class Local {

    private String idlocal;
    private String idencargado;

    public Local() {
    }

    public Local(String idlocal, String idencargado) {
        this.idlocal = idlocal;
        this.idencargado = idencargado;
    }

    public String getIdlocal() {
        return idlocal;
    }

    public void setIdlocal(String idlocal) {
        this.idlocal = idlocal;
    }

    public String getIdencargado() {
        return idencargado;
    }

    public void setIdencargado(String idencargado) {
        this.idencargado = idencargado;
    }
}
