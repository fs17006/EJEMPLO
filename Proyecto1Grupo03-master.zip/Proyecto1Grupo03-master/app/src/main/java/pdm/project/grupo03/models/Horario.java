package pdm.project.grupo03.models;

public class Horario {

    private int idhora;
    private String hora;

    public Horario() {
    }

    public Horario(int idhora, String hora) {
        this.idhora = idhora;
        this.hora = hora;
    }

    public int getIdhorario() {
        return idhora;
    }

    public void setIdhorario(int idhorario) {
        this.idhora = idhorario;
    }

    public String getHorario() {
        return hora;
    }

    public void setHorario(String horario) {
        this.hora = horario;
    }
}
