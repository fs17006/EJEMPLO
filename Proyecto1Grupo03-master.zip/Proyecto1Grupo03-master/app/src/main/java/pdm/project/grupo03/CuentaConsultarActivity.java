package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.List;
import java.util.Objects;

import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.TipoUsuario;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.TipoUsuarioRepository;
import pdm.project.grupo03.repositories.UsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class CuentaConsultarActivity extends AppCompatActivity {

    EditText txtNombre;
    EditText txtUser;
    EditText txtTipoCuenta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuenta_consultar);
        txtNombre = findViewById(R.id.perfil_nombre);
        txtUser = findViewById(R.id.perfil_user);
        txtTipoCuenta = findViewById(R.id.perfil_tipo_cuenta);
        initPantalla();
    }

    private void initPantalla(){
        DatabaseOperations.abrirConexion();
        Usuario usuario = UsuarioRepository.consultar(Utils.loggedUser.getUser());
        TipoUsuario tipoUsuario = TipoUsuarioRepository.consultar(usuario.getTipoUser());
        List<Profesor> profesor = ProfesorRepository.consultar("user = ?", new String[]{usuario.getUser() });
        DatabaseOperations.cerrarConexion();
        if(Objects.nonNull(usuario)){
            txtNombre.setText(profesor.isEmpty() ? "admin" : profesor.get(0).getNombre() + " " + profesor.get(0).getApellido());
            txtUser.setText(usuario.getUser());
            txtTipoCuenta.setText(tipoUsuario.getTipoUsuario());
        }
    }

    public void cerrarSesion(View view){
        try {
            Utils.loggedUser = null;
            Intent intent = new Intent(this, Rutas.getClase("LoginActivity"));
            this.startActivity(intent);
        }catch(ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }
}