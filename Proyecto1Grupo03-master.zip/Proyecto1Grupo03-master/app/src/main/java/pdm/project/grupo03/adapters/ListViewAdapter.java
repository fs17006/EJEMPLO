package pdm.project.grupo03.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import pdm.project.grupo03.R;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.enums.ENUMS;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Propuesta;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.DiaRepository;
import pdm.project.grupo03.repositories.EstadoRepository;
import pdm.project.grupo03.repositories.HorarioRepository;
import pdm.project.grupo03.repositories.LocalRepository;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.repositories.TipoUsuarioRepository;
import pdm.project.grupo03.repositories.UsuarioRepository;

public class ListViewAdapter<T> extends BaseAdapter {

    private Context context;
    private int layout;
    private ArrayList<T> items;
    private ENUMS.TABLAS tabla;

    public ListViewAdapter(Context context, int layout, ArrayList<T> items, ENUMS.TABLAS tabla){
        this.context = context;
        this.layout = layout;
        this.items = items;
        this.tabla = tabla;
    }

    @Override
    public int getCount() {
        return this.items.size();
    }

    @Override
    public T getItem(int i) {
        return this.items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);
        View v = null;
        DatabaseOperations.abrirConexion();
        switch (this.tabla){
            case USUARIO:{
                v = layoutInflater.inflate(R.layout.users_list_item, null);
                Usuario usuario = (Usuario) getItem(i);
                TextView txtNombre = v.findViewById(R.id.user);
                txtNombre.setText(usuario.getUser());
                TextView txtTipoUser = v.findViewById(R.id.tipo_user);
                txtTipoUser.setText(TipoUsuarioRepository.consultar(usuario.getTipoUser()).getTipoUsuario());
                break;
            }
            case MATERIA:{
                v = layoutInflater.inflate(R.layout.materias_list_item, null);
                Materia materia = (Materia) getItem(i);
                TextView txtCodmateria = v.findViewById(R.id.txt_codmateria);
                txtCodmateria.setText(materia.getCodmateria());
                TextView txtNommateria = v.findViewById(R.id.txt_nombre_materia);
                txtNommateria.setText(materia.getNombre());
                TextView txtNumciclo = v.findViewById(R.id.txt_ciclo);
                txtNumciclo.setText("CICLO " + materia.getNumciclo());
                break;
            }
            case PROPUESTA:{
                v = layoutInflater.inflate(R.layout.propuestas_list_item, null);
                Propuesta propuesta = (Propuesta) getItem(i);
                TextView txtLocal = v.findViewById(R.id.txt_local_propuestas);
                txtLocal.setText(propuesta.getIdlocal());
                TextView txtCodmateria = v.findViewById(R.id.txt_codmateria_propuestas);
                txtCodmateria.setText(propuesta.getCodmateria());
                TextView txtDia = v.findViewById(R.id.txt_dia_propuestas);
                txtDia.setText(DiaRepository.consultar("iddia = ?", new String[]{String.valueOf(propuesta.getIddia())}).get(0).getDia());
                TextView txtHora = v.findViewById(R.id.txt_hora_propuestas);
                txtHora.setText(HorarioRepository.consultar("idhora = ?", new String[]{String.valueOf(propuesta.getIdhora())}).get(0).getHorario());
                TextView txtEstado = v.findViewById(R.id.txt_estado_propuestas);
                txtEstado.setText(EstadoRepository.consultar("idestado = ?", new String[]{String.valueOf(propuesta.getIdestado())}).get(0).getEstado());
                break;
            }
            case PROFESOR:{
                v = layoutInflater.inflate(R.layout.profesor_list_item, null);
                Profesor profesor = (Profesor) getItem(i);
                TextView txtCodigo = v.findViewById(R.id.txt_codigo_profesor);
                txtCodigo.setText(profesor.getIdprofesor());
                TextView txtNombre = v.findViewById(R.id.txt_nombre_apellido);
                txtNombre.setText(profesor.getNombre() + " " + profesor.getApellido());
                TextView txtCargo = v.findViewById(R.id.txt_cargo);
                txtCargo.setText(Objects.equals(profesor.getIdcargo(), 3) ? "Local: " : "Materia: ");
                TextView txtMateriaLocal = v.findViewById(R.id.txt_materia_local);
                if(Objects.equals(profesor.getIdcargo(), 2)){

                    List<Materia> materias = MateriaRepository.consultar("coordinador = ?", new String[]{ profesor.getIdprofesor() });
                    if(!materias.isEmpty()){
                        txtMateriaLocal.setText(materias.get(0).getCodmateria());
                    }else{
                        txtMateriaLocal.setText(R.string.profesores_sin_materia_asignada);
                    }
                }
                if(Objects.equals(profesor.getIdcargo(), 3)){
                    List<Local> locales = LocalRepository.consultar("idencargado = ?", new String[]{profesor.getIdprofesor() });
                    if(!locales.isEmpty()){
                        StringBuilder localesAsignados = new StringBuilder();
                        locales.stream().map(Local::getIdlocal).forEach(l -> {
                            localesAsignados.append(l).append(",");
                        });
                        txtMateriaLocal.setText(localesAsignados.substring(0, localesAsignados.toString().length() - 1));
                    }else{
                        txtMateriaLocal.setText(R.string.profesores_sin_local_asignado);
                    }
                }


                TextView txtUsuario = v.findViewById(R.id.txt_usuario_profesor);
                txtUsuario.setText(!Objects.isNull(profesor.getUser()) ? profesor.getUser() : "Sin usuario");
                break;
            }
        }
        DatabaseOperations.cerrarConexion();
        return v;
    }
}
