package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.TipoActividad;

public class TipoActividadRepository {

    private static final String TABLA = "tipoactividad";

    public static void guardar(TipoActividad tipoActividad){
        ContentValues cv = new ContentValues();
        cv.put("idtipoactividad", tipoActividad.getIdTipoActividad());
        cv.put("tipoactividad", tipoActividad.getTipoActividad());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<TipoActividad> consultar(String condiciones, String[] argumentos){
        List<TipoActividad> tiposActividad = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return tiposActividad;
        }
        while(!cursor.isAfterLast()){
            TipoActividad tipoActividad = new TipoActividad();
            tipoActividad.setIdTipoActividad(cursor.getInt(0));
            tipoActividad.setTipoActividad(cursor.getString(1));
            tiposActividad.add(tipoActividad);
            cursor.moveToNext();
        }
        cursor.close();
        return tiposActividad;
    }

}
