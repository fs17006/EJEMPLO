package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ProfesoresActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profesores);
    }
}