package pdm.project.grupo03.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

import pdm.project.grupo03.R;
import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.models.MenuItem;

public class MenuAdapter extends ArrayAdapter<MenuItem> {

    public MenuAdapter(@NonNull Context context, ArrayList<MenuItem> items) {
        super(context, 0, items);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemsView = convertView;
        if(Objects.isNull(listItemsView)){
            listItemsView = LayoutInflater.from(getContext()).inflate(R.layout.grid_item_card, parent, false);
        }
        MenuItem menuItem = getItem(position);
        assert listItemsView != null;
        TextView name = listItemsView.findViewById(R.id.menu_item_name);
        ImageView icon = listItemsView.findViewById(R.id.menu_item_icon);
        name.setText(menuItem.nombre);
        icon.setImageResource(menuItem.iconResource);
        return listItemsView;
    }
}
