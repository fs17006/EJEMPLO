package pdm.project.grupo03.routing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import pdm.project.grupo03.R;
import pdm.project.grupo03.models.MenuItem;

public class Rutas {

    private static final String NOMBRE_PAQUETE = "pdm.project.grupo03.";

    private static ArrayList<MenuItem> rutasMenuPpal
            = new ArrayList<>(Arrays.asList(
                    new MenuItem("Solicitudes", R.drawable.solicitud, "SolicitudesActivity", new Integer[]{1,3}),
                    new MenuItem("Propuestas", R.drawable.propuesta, "PropuestasActivity", new Integer[]{1,2}),
                    new MenuItem("Profesores", R.drawable.people, "EncargadosActivity", new Integer[]{1,2,3}),
                    new MenuItem("Materias", R.drawable.materias, "MateriasActivity", new Integer[]{1,2,3}),
                    new MenuItem("Usuarios", R.drawable.mantenimiento_usuarios, "UsuariosActivity", new Integer[]{1})

            )) ;

    public static Class<?> getClase(String activityName) throws ClassNotFoundException {
        return Class.forName(new StringBuilder(NOMBRE_PAQUETE).append(activityName).toString());
    }

    public static ArrayList<MenuItem> getRutasMenuPpal(){
        return rutasMenuPpal;
    }
}
