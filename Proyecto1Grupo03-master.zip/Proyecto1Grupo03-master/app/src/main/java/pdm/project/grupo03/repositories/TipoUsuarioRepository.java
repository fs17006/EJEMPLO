package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.TipoUsuario;
import pdm.project.grupo03.models.Usuario;

public class TipoUsuarioRepository {

    private static final String TABLA = "tipousuario";

    public static void guardar(TipoUsuario tipoUsuario){
        ContentValues cv = new ContentValues();
        cv.put("idtipousuario", tipoUsuario.getIdTipoUsuario());
        cv.put("tipousuario", tipoUsuario.getTipoUsuario());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<TipoUsuario> consultar(){
        List<TipoUsuario> tiposUsuario = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, null, null, null, null, null);
        if(!cursor.moveToFirst()){
            return tiposUsuario;
        }
        while(!cursor.isAfterLast()){
            TipoUsuario tipoUsuario = new TipoUsuario();
            tipoUsuario.setIdTipoUsuario(cursor.getInt(0));
            tipoUsuario.setTipoUsuario(cursor.getString(1));
            tiposUsuario.add(tipoUsuario);
            cursor.moveToNext();
        }
        cursor.close();
        return tiposUsuario;
    }

    public static TipoUsuario consultar(int idTipoUsuario){
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, "idtipousuario = ?", new String[]{ String.valueOf(idTipoUsuario) }, null, null, null);
        TipoUsuario tipoUsuario = null;
        if(cursor.moveToFirst()){
            tipoUsuario = new TipoUsuario();
            tipoUsuario.setIdTipoUsuario(cursor.getInt(0));
            tipoUsuario.setTipoUsuario(cursor.getString(1));
        }
        cursor.close();
        return tipoUsuario;
    }

}
