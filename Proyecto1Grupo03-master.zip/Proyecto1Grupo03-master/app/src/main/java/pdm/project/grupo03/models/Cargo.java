package pdm.project.grupo03.models;

public class Cargo {

    private int idcargo;
    private String cargo;

    public Cargo() {
    }

    public Cargo(int idcargo, String cargo) {
        this.idcargo = idcargo;
        this.cargo = cargo;
    }

    public int getIdcargo() {
        return idcargo;
    }

    public void setIdcargo(int idcargo) {
        this.idcargo = idcargo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
}
