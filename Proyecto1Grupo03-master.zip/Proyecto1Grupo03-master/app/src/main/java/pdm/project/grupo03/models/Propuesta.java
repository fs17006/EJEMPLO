package pdm.project.grupo03.models;

import java.io.Serializable;

public class Propuesta implements Serializable {

    private int idpropuesta;
    private String idciclo;
    private String codmateria;
    private String idlocal;
    private int idtipoactividad;
    private int iddia;
    private int idhora;
    private int grupo;
    private String user;
    private int idestado;

    public Propuesta() {
    }

    public Propuesta(int idpropuesta, String idciclo, String codmateria, String idlocal, int idtipoactividad, int iddia, int idhora, int grupo, String user, int idestado) {
        this.idpropuesta = idpropuesta;
        this.idciclo = idciclo;
        this.codmateria = codmateria;
        this.idlocal = idlocal;
        this.idtipoactividad = idtipoactividad;
        this.iddia = iddia;
        this.idhora = idhora;
        this.grupo = grupo;
        this.user = user;
        this.idestado = idestado;
    }

    public int getIdpropuesta() {
        return idpropuesta;
    }

    public void setIdpropuesta(int idpropuesta) {
        this.idpropuesta = idpropuesta;
    }

    public String getIdciclo() {
        return idciclo;
    }

    public void setIdciclo(String idciclo) {
        this.idciclo = idciclo;
    }

    public String getCodmateria() {
        return codmateria;
    }

    public void setCodmateria(String codmateria) {
        this.codmateria = codmateria;
    }

    public String getIdlocal() {
        return idlocal;
    }

    public void setIdlocal(String idlocal) {
        this.idlocal = idlocal;
    }

    public int getIdtipoactividad() {
        return idtipoactividad;
    }

    public void setIdtipoactividad(int idtipoactividad) {
        this.idtipoactividad = idtipoactividad;
    }

    public int getIddia() {
        return iddia;
    }

    public void setIddia(int iddia) {
        this.iddia = iddia;
    }

    public int getIdhora() {
        return idhora;
    }

    public void setIdhora(int idhora) {
        this.idhora = idhora;
    }

    public int getGrupo() {
        return grupo;
    }

    public void setGrupo(int grupo) {
        this.grupo = grupo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getIdestado() {
        return idestado;
    }

    public void setIdestado(int idestado) {
        this.idestado = idestado;
    }
}
