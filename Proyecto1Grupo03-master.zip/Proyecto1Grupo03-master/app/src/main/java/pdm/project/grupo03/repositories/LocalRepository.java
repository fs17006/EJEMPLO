package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.Materia;

public class LocalRepository {

    private static final String TABLA = "local";

    public static void guardar(Local local){
        ContentValues cv = new ContentValues();
        cv.put("idlocal", local.getIdlocal());
        cv.put("idencargado", local.getIdencargado());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Local> consultar(String condiciones, String[] argumentos){
        List<Local> locales = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return locales;
        }
        while(!cursor.isAfterLast()){
            Local local = new Local();
            local.setIdlocal(cursor.getString(0));
            local.setIdencargado(cursor.getString(1));
            locales.add(local);
            cursor.moveToNext();
        }
        cursor.close();
        return locales;
    }

}
