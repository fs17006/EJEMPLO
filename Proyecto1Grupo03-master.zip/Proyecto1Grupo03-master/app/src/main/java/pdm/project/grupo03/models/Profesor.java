package pdm.project.grupo03.models;

import java.io.Serializable;

public class Profesor implements Serializable {

    private String idprofesor;
    private String nombre;
    private String apellido;
    private int idcargo;
    private String user;

    public Profesor() {
    }

    public Profesor(String idprofesor, String nombre, String apellido, int idcargo, String user) {
        this.idprofesor = idprofesor;
        this.nombre = nombre;
        this.apellido = apellido;
        this.idcargo = idcargo;
        this.user = user;
    }

    public String getIdprofesor() {
        return idprofesor;
    }

    public void setIdprofesor(String idprofesor) {
        this.idprofesor = idprofesor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getIdcargo() {
        return idcargo;
    }

    public void setIdcargo(int idcargo) {
        this.idcargo = idcargo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
