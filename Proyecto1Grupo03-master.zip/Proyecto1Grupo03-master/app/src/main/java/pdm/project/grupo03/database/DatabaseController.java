package pdm.project.grupo03.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseController {

    private Context context;
    public static DatabaseHelper databaseHelper;
    public static SQLiteDatabase sqLiteDatabase;

    public DatabaseController(Context context){
        this.context = context;
        databaseHelper = new DatabaseHelper(context);
    }

    public static class DatabaseHelper extends SQLiteOpenHelper{

        private static final String DB_NAME = "projectGrupo03DB.s3db";
        private static final int DB_VERSION = 1;

        public DatabaseHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            Log.i("INFO:", "onCreate");
            DatabaseOperations.crearDatabase(sqLiteDatabase);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        }
    }

}
