package pdm.project.grupo03.models;

public class SolicitudDeta {

    private int idsolicitud;
    private int idpropuesta;

    public SolicitudDeta() {
    }

    public SolicitudDeta(int idsolicitud, int idpropuesta) {
        this.idsolicitud = idsolicitud;
        this.idpropuesta = idpropuesta;
    }

    public int getIdsolicitud() {
        return idsolicitud;
    }

    public void setIdsolicitud(int idsolicitud) {
        this.idsolicitud = idsolicitud;
    }

    public int getIdpropuesta() {
        return idpropuesta;
    }

    public void setIdpropuesta(int idpropuesta) {
        this.idpropuesta = idpropuesta;
    }
}
