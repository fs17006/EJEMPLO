package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Ciclo;
import pdm.project.grupo03.models.Dia;
import pdm.project.grupo03.models.Estado;
import pdm.project.grupo03.models.Horario;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Propuesta;
import pdm.project.grupo03.models.TipoActividad;
import pdm.project.grupo03.repositories.CicloRepository;
import pdm.project.grupo03.repositories.DiaRepository;
import pdm.project.grupo03.repositories.EstadoRepository;
import pdm.project.grupo03.repositories.HorarioRepository;
import pdm.project.grupo03.repositories.LocalRepository;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.PropuestaRepository;
import pdm.project.grupo03.repositories.TipoActividadRepository;
import pdm.project.grupo03.routing.Rutas;

public class PropuestasEditarActivity extends AppCompatActivity {

    Propuesta propuesta;
    TextView txtCorrelativo;
    TextView txtCiclo;
    TextView txtEstado;
    Spinner spnMateria;
    Spinner spnTipoActividad;
    EditText editGrupo;
    Spinner spnLocal;
    Spinner spnDia;
    Spinner spnHorario;
    List<Materia> materias;
    List<TipoActividad> tipoActividades;
    Ciclo ciclo;
    List<Local> locales;
    List<Dia> dias;
    List<Horario> horarios;
    List<Estado> estados;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_propuestas_editar);
        initPantalla();
    }

    private void initPantalla(){
        propuesta = (Propuesta) this.getIntent().getSerializableExtra("propuesta");
        txtCorrelativo = findViewById(R.id.txt_correlativo_edit_propuesta);
        txtCiclo = findViewById(R.id.txt_ciclo_edit_propuesta);
        txtEstado = findViewById(R.id.txt_estado_edit_propuesta);
        spnMateria = findViewById(R.id.spn_materia_edit_propuesta);
        spnTipoActividad = findViewById(R.id.spn_tipo_actividad_edit_propuesta);
        editGrupo = findViewById(R.id.edit_grupo_edit_propuesta);
        spnLocal = findViewById(R.id.spn_local_edit_propuesta);
        spnDia = findViewById(R.id.spn_dia_edit_propuesta);
        spnHorario = findViewById(R.id.spn_horario_edit_propuesta);
        DatabaseOperations.abrirConexion();
        List<Profesor> profesores = ProfesorRepository.consultar("user = ?", new String[]{ Utils.loggedUser.getUser() });
        Profesor profesor = null;
        if(!profesores.isEmpty()){
            profesor = profesores.get(0);
        }
        assert profesor != null;
        materias = MateriaRepository.consultar("coordinador = ?", new String[]{ profesor.getIdprofesor() });
        ciclo = CicloRepository.consultarCicloActual();
        locales = LocalRepository.consultar(null, null);
        dias = DiaRepository.consultar(null, null);

        horarios = HorarioRepository.consultar(null, null);
        tipoActividades = TipoActividadRepository.consultar(null, null);
        estados = EstadoRepository.consultar(null, null);
        DatabaseOperations.cerrarConexion();

        txtCorrelativo.setText(String.valueOf(propuesta.getIdpropuesta()));
        txtCiclo.setText(propuesta.getIdciclo());
        txtEstado.setText(estados.stream().filter(e -> Objects.equals(e.getIdestado(), propuesta.getIdestado())).collect(Collectors.toList()).get(0).getEstado());
        spnMateria.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, materias.stream().map(Materia::getNombre).collect(Collectors.toList())));
        spnLocal.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, locales.stream().map(Local::getIdlocal).collect(Collectors.toList())));
        spnDia.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, dias.stream().map(Dia::getDia).collect(Collectors.toList())));
        spnHorario.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, horarios.stream().map(Horario::getHorario).collect(Collectors.toList())));
        spnTipoActividad.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tipoActividades.stream().map(TipoActividad::getTipoActividad).collect(Collectors.toList())));
        spnMateria.setSelection(materias.indexOf(materias.stream().filter(m -> m.getCodmateria().equals(propuesta.getCodmateria())).collect(Collectors.toList()).get(0)));
        spnTipoActividad.setSelection(tipoActividades.indexOf(tipoActividades.stream().filter(ta -> Objects.equals(ta.getIdTipoActividad(), propuesta.getIdtipoactividad())).collect(Collectors.toList()).get(0)));
        editGrupo.setText(String.valueOf(propuesta.getGrupo()));
        spnLocal.setSelection(locales.indexOf(locales.stream().filter(l -> l.getIdlocal().equals(propuesta.getIdlocal())).collect(Collectors.toList()).get(0)));
        spnDia.setSelection(dias.indexOf(dias.stream().filter(d -> Objects.equals(d.getIddia(), propuesta.getIddia())).collect(Collectors.toList()).get(0)));
        spnHorario.setSelection(horarios.indexOf(horarios.stream().filter(h -> Objects.equals(h.getIdhorario(), propuesta.getIdhora())).collect(Collectors.toList()).get(0)));
    }

    public void actualizar(View view) throws ClassNotFoundException {
        if(TextUtils.isEmpty(editGrupo.getText())){
            Toast.makeText(this, "El grupo no puede estar vacio", Toast.LENGTH_SHORT).show();
            return;
        }
        if(!Objects.equals(propuesta.getIdestado(), 1)){
            Toast.makeText(this, "No se puede actualizar en este estado", Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseOperations.abrirConexion();
        Propuesta prop = new Propuesta();
        prop.setCodmateria(materias.stream().filter(m -> m.getNombre().equals(spnMateria.getSelectedItem())).collect(Collectors.toList()).get(0).getCodmateria());
        prop.setGrupo(Integer.parseInt(editGrupo.getText().toString()));
        prop.setIddia(dias.stream().filter(d -> d.getDia().equals(spnDia.getSelectedItem())).collect(Collectors.toList()).get(0).getIddia());
        prop.setIdciclo(ciclo.getIdciclo());
        prop.setIdestado(1);
        prop.setIdhora(horarios.stream().filter(h -> h.getHorario().equals(spnHorario.getSelectedItem())).collect(Collectors.toList()).get(0).getIdhorario());
        prop.setUser(propuesta.getUser());
        prop.setIdlocal(locales.stream().filter(l -> l.getIdlocal().equals(spnLocal.getSelectedItem())).collect(Collectors.toList()).get(0).getIdlocal());
        prop.setIdpropuesta(propuesta.getIdpropuesta());
        prop.setIdtipoactividad(tipoActividades.stream().filter(ta -> ta.getTipoActividad().equals(spnTipoActividad.getSelectedItem())).collect(Collectors.toList()).get(0).getIdTipoActividad());
        PropuestaRepository.actualizar(prop);
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("PropuestasActivity")));
        this.finish();
    }

    public void eliminar(View view) throws ClassNotFoundException {
        if(!Objects.equals(propuesta.getIdestado(), 1)){
            Toast.makeText(this, "No se puede eliminar en este estado", Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseOperations.abrirConexion();
        PropuestaRepository.eliminar(String.valueOf(propuesta.getIdpropuesta()));
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("PropuestasActivity")));
        this.finish();
    }

    public void enviar(View view){
        if(!Objects.equals(propuesta.getIdestado(), 1)){
            Toast.makeText(this, "No se puede enviar la propuesta en este estado", Toast.LENGTH_SHORT).show();
            return;
        }
        Propuesta prop = new Propuesta();
        prop.setCodmateria(materias.stream().filter(m -> m.getNombre().equals(spnMateria.getSelectedItem())).collect(Collectors.toList()).get(0).getCodmateria());
        prop.setGrupo(Integer.parseInt(editGrupo.getText().toString()));
        prop.setIddia(dias.stream().filter(d -> d.getDia().equals(spnDia.getSelectedItem())).collect(Collectors.toList()).get(0).getIddia());
        prop.setIdciclo(ciclo.getIdciclo());
        prop.setIdestado(2);
        prop.setIdhora(horarios.stream().filter(h -> h.getHorario().equals(spnHorario.getSelectedItem())).collect(Collectors.toList()).get(0).getIdhorario());
        prop.setUser(propuesta.getUser());
        prop.setIdlocal(locales.stream().filter(l -> l.getIdlocal().equals(spnLocal.getSelectedItem())).collect(Collectors.toList()).get(0).getIdlocal());
        prop.setIdpropuesta(propuesta.getIdpropuesta());
        prop.setIdtipoactividad(tipoActividades.stream().filter(ta -> ta.getTipoActividad().equals(spnTipoActividad.getSelectedItem())).collect(Collectors.toList()).get(0).getIdTipoActividad());
        DatabaseOperations.abrirConexion();
        PropuestaRepository.actualizar(prop);
        DatabaseOperations.cerrarConexion();
        txtEstado.setText(estados.stream().filter(e -> Objects.equals(e.getIdestado(), 2)).collect(Collectors.toList()).get(0).getEstado());
        propuesta.setIdestado(2);
        Toast.makeText(this, "Enviado correctamente", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        try {
            this.startActivity(new Intent(this, Rutas.getClase("PropuestasActivity")));
            this.finish();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}