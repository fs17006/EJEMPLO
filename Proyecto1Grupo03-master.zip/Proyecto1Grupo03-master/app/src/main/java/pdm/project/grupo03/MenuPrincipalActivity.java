package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

import pdm.project.grupo03.adapters.MenuAdapter;
import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.models.MenuItem;
import pdm.project.grupo03.routing.Rutas;

public class MenuPrincipalActivity extends AppCompatActivity {

    GridView gridMenuPpal;
    ArrayList<MenuItem> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);
        items = Rutas.getRutasMenuPpal().stream().filter(mi -> Arrays.asList(mi.permisos).contains(Utils.loggedUser.getTipoUser())).collect(Collectors.toCollection(ArrayList::new));
        gridMenuPpal = findViewById(R.id.menu_ppal_grid);
        gridMenuPpal.setAdapter(new MenuAdapter(this, items));
        gridMenuPpal.setOnItemClickListener((adapterView, view, i, l) -> {
            try {
                Intent intent = new Intent(this, Rutas.getClase(items.get(i).activityName));
                this.startActivity(intent);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }

    public void consultarCuenta(View view){
        try{
            Intent intent = new Intent(this, Rutas.getClase("CuentaConsultarActivity"));
            this.startActivity(intent);
        }catch (ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }

}