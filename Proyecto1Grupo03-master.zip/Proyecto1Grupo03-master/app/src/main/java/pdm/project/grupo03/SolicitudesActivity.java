package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.adapters.ListViewAdapter;
import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.enums.ENUMS;
import pdm.project.grupo03.models.Ciclo;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Propuesta;
import pdm.project.grupo03.models.Solicitud;
import pdm.project.grupo03.models.SolicitudDeta;
import pdm.project.grupo03.repositories.CicloRepository;
import pdm.project.grupo03.repositories.HorarioRepository;
import pdm.project.grupo03.repositories.LocalRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.PropuestaRepository;
import pdm.project.grupo03.repositories.SolicitudDetaRepository;
import pdm.project.grupo03.repositories.SolicitudRepository;

public class SolicitudesActivity extends AppCompatActivity {

    Spinner spnLocales;
    ListView lstViewPropuestas;
    Profesor profesor;
    List<Local> locales;
    List<Propuesta> propuestas;
    Ciclo ciclo;
    Solicitud solicitud;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solicitudes);
        initPantalla();
    }

    private void initPantalla(){
        spnLocales = findViewById(R.id.spn_local_solicitudes);
        lstViewPropuestas = findViewById(R.id.listView_propuestas_solicitudes);
        DatabaseOperations.abrirConexion();
        profesor = ProfesorRepository.consultar(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? null : "user = ?", Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? null : new String[]{Utils.loggedUser.getUser() }).get(0);
        locales = LocalRepository.consultar(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? null : "idencargado = ?", Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? null : new String[]{ profesor.getIdprofesor() });
        ciclo = CicloRepository.consultarCicloActual();
        DatabaseOperations.cerrarConexion();
        spnLocales.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, locales.stream().map(Local::getIdlocal).collect(Collectors.toList())));
        spnLocales.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                loadPropuestas(spnLocales.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        loadPropuestas(spnLocales.getSelectedItem().toString());
    }

    private void loadPropuestas(String idlocal){
        DatabaseOperations.abrirConexion();
        propuestas = PropuestaRepository.consultar("idlocal = ? AND idestado <> ?", new String[]{ idlocal, String.valueOf(1) });
        List<Solicitud> solicitudes = SolicitudRepository.consultar("idlocal = ? AND idciclo = ?", new String[]{ idlocal, ciclo.getIdciclo() });
        if(solicitudes.isEmpty()){
            int correlativo = SolicitudRepository.consultar(null, null).size() + 1;
            SolicitudRepository.guardar(new Solicitud(correlativo, ciclo.getIdciclo(), idlocal, 1, 0));
        }
        solicitud = SolicitudRepository.consultar(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? null : "idlocal = ? AND idciclo = ?", Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? null : new String[]{ idlocal, ciclo.getIdciclo() }).get(0);
        DatabaseOperations.cerrarConexion();
        lstViewPropuestas.setAdapter(new ListViewAdapter<>(this, R.layout.propuestas_list_item, new ArrayList<>(propuestas), ENUMS.TABLAS.PROPUESTA));
        lstViewPropuestas.setOnItemClickListener((adapterView, view, i, l) -> {
            if(!Objects.equals(Utils.loggedUser.getTipoUser(), 1)){
                showDialog(propuestas.get(i));
            }
        });
    }

    private void showDialog(Propuesta propuesta){

        Button btnConfirmar;
        Button btnRechazar;
        boolean existe = false;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.solicitudes_alert_dialog, findViewById(R.id.layoutDialogContainer));
        builder.setView(view);
        DatabaseOperations.abrirConexion();
        ((TextView) view.findViewById(R.id.textTitle))
                .setText("Propuesta: " + propuesta.getCodmateria() + " - " + HorarioRepository.consultar("idhora = ?", new String[]{ String.valueOf(propuesta.getIdhora()) }).get(0).getHorario());

        btnRechazar = view.findViewById(R.id.buttonYes);
        btnConfirmar = view.findViewById(R.id.buttonNo);

        List<Propuesta> propuestasxHorario = PropuestaRepository.consultar("idpropuesta <> ? AND idlocal = ? AND iddia = ? AND idhora = ? AND idestado = ?", new String[]{ String.valueOf(propuesta.getIdpropuesta()), propuesta.getIdlocal(), String.valueOf(propuesta.getIddia()), String.valueOf(propuesta.getIdhora()), String.valueOf(3)});
        Propuesta propuestaExiste = null;
        if(!propuestasxHorario.isEmpty()){
            existe = true;
            propuestaExiste = propuestasxHorario.get(0);
        }
        ((TextView) view.findViewById(R.id.textMessage))
                .setText(existe ? "Ya se ha registrado la materia: " + propuestaExiste.getCodmateria() + " - Grupo: " + propuestaExiste.getGrupo() + " para este horario" : "");
        DatabaseOperations.cerrarConexion();
        AlertDialog dialog = builder.create();

        boolean finalExiste = existe;
        Propuesta finalPropuestaExiste = propuestaExiste;
        btnConfirmar.setOnClickListener(v -> {
            if(Objects.equals(propuesta.getIdestado(), 3)){
                Toast.makeText(this, "Este horario ya se encuentra confirmado", Toast.LENGTH_SHORT).show();
                return;
            }
            DatabaseOperations.abrirConexion();
            if(finalExiste){
                SolicitudDetaRepository.eliminar(solicitud.getIdsolicitud(), finalPropuestaExiste.getIdpropuesta());
                finalPropuestaExiste.setIdestado(4);
                PropuestaRepository.actualizar(finalPropuestaExiste);
            }
            propuesta.setIdestado(3);
            PropuestaRepository.actualizar(propuesta);
            SolicitudDetaRepository.guardar(new SolicitudDeta(solicitud.getIdsolicitud(), propuesta.getIdpropuesta()));
            DatabaseOperations.cerrarConexion();
            dialog.dismiss();
            loadPropuestas(spnLocales.getSelectedItem().toString());
        });

        btnRechazar.setOnClickListener(v -> {
            if(Objects.equals(propuesta.getIdestado(), 4)){
                Toast.makeText(this, "Este horario ya se encuentra rechazado", Toast.LENGTH_SHORT).show();
                return;
            }
            DatabaseOperations.abrirConexion();
            propuesta.setIdestado(4);
            PropuestaRepository.actualizar(propuesta);
            DatabaseOperations.cerrarConexion();
            dialog.dismiss();
            loadPropuestas(spnLocales.getSelectedItem().toString());
        });
        dialog.show();
    }

}