package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.routing.Rutas;

public class MainActivity extends AppCompatActivity {

    DatabaseController databaseController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try{
            databaseController = new DatabaseController(this);
            DatabaseOperations.abrirConexion();
            DatabaseOperations.inicializarDatabase();
            DatabaseOperations.cerrarConexion();
            Intent intent = new Intent(this, Rutas.getClase("LoginActivity"));
            this.startActivity(intent);
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "Ha ocurrido un error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}