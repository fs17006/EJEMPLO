package pdm.project.grupo03.models;

public class TipoActividad {

    private int idTipoActividad;
    private String tipoActividad;

    public TipoActividad() {
    }

    public TipoActividad(int idTipoActividad, String tipoActividad) {
        this.idTipoActividad = idTipoActividad;
        this.tipoActividad = tipoActividad;
    }

    public int getIdTipoActividad() {
        return idTipoActividad;
    }

    public void setIdTipoActividad(int idTipoActividad) {
        this.idTipoActividad = idTipoActividad;
    }

    public String getTipoActividad() {
        return tipoActividad;
    }

    public void setTipoActividad(String tipoActividad) {
        this.tipoActividad = tipoActividad;
    }
}
