package pdm.project.grupo03.models;

import java.util.ArrayList;
import java.util.List;

public class MenuItem {

    public String nombre;
    public int iconResource;
    public String activityName;
    public Integer[] permisos;

    public MenuItem(String nombre, int iconResource, String activityName, Integer[] permisos) {
        this.nombre = nombre;
        this.iconResource = iconResource;
        this.activityName = activityName;
        this.permisos = permisos;
    }
}
