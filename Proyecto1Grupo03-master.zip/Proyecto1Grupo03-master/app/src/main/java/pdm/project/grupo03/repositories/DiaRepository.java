package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Ciclo;
import pdm.project.grupo03.models.Dia;
import pdm.project.grupo03.models.Local;

public class DiaRepository {

    private static final String TABLA = "dia";

    public static void guardar(Dia dia){
        ContentValues cv = new ContentValues();
        cv.put("iddia", dia.getIddia());
        cv.put("dia", dia.getDia());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Dia> consultar(String condiciones, String[] argumentos){
        List<Dia> dias = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return dias;
        }
        while(!cursor.isAfterLast()){
            Dia dia = new Dia();
            dia.setIddia(cursor.getInt(0));
            dia.setDia(cursor.getString(1));
            dias.add(dia);
            cursor.moveToNext();
        }
        cursor.close();
        return dias;
    }

}
