package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Propuesta;
import pdm.project.grupo03.models.Solicitud;

public class SolicitudRepository {

    public static final String TABLA = "solicitud";

    public static void guardar(Solicitud solicitud){
        ContentValues cv = new ContentValues();
        cv.put("idsolicitud", solicitud.getIdsolicitud());
        cv.put("idciclo", solicitud.getIdciclo());
        cv.put("idlocal", solicitud.getIdlocal());
        cv.put("idestado", solicitud.getIdestado());
        cv.put("enviado", solicitud.getEnviado());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Solicitud> consultar(String condiciones, String[] argumentos){
        List<Solicitud> solicitudes = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return solicitudes;
        }
        while(!cursor.isAfterLast()){
            Solicitud solicitud = new Solicitud();
            solicitud.setIdsolicitud(cursor.getInt(0));
            solicitud.setIdciclo(cursor.getString(0));
            solicitud.setIdlocal(cursor.getString(2));
            solicitud.setIdestado(cursor.getInt(3));
            solicitud.setEnviado(cursor.getInt(4));
            solicitudes.add(solicitud);
            cursor.moveToNext();
        }
        cursor.close();
        return solicitudes;
    }

}
