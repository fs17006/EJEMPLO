package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Cargo;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.CargoRepository;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.UsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class EncargadosEditarActivity extends AppCompatActivity {

    Profesor profesor;
    EditText editNombre;
    EditText editApellido;
    Spinner spnUsuario;
    Spinner spnCargo;
    CheckBox chkAsignar;
    Button btnActualizarProfesor;
    Button btnEliminarProfesor;

    List<Cargo> cargos;
    List<Usuario> usuarios;
    List<Profesor> profesores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encargados_editar);
        profesor = (Profesor) getIntent().getSerializableExtra("profesor");
        editNombre = findViewById(R.id.edit_nombre_edit_encargados);
        editApellido = findViewById(R.id.edit_apellido_edit_encargados);
        spnCargo = findViewById(R.id.spn_cargo_edit_encargados);
        spnUsuario = findViewById(R.id.spn_usuario_edit_encargados);
        chkAsignar = findViewById(R.id.chk_asignar_cuenta_edit);
        btnActualizarProfesor = findViewById(R.id.btn_actualizar_profesor);
        btnEliminarProfesor = findViewById(R.id.btn_eliminar_profesor);
        btnActualizarProfesor.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.VISIBLE : View.INVISIBLE);
        btnEliminarProfesor.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.VISIBLE : View.INVISIBLE);
        DatabaseOperations.abrirConexion();
        cargos = CargoRepository.consultar(null, null);
        profesores = ProfesorRepository.consultar("user is not null", null);
        StringBuilder list = new StringBuilder("(");
        profesores.forEach(p -> list.append("'").append(p.getUser()).append("'").append(","));
        usuarios = UsuarioRepository.consultar("user <> ?" , new String[]{ "admin" });
        DatabaseOperations.cerrarConexion();
        editNombre.setText(profesor.getNombre());
        editApellido.setText(profesor.getApellido());
        spnUsuario.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, usuarios.stream().map(Usuario::getUser).collect(Collectors.toList())));
        spnCargo.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, cargos.stream().map(Cargo::getCargo).collect(Collectors.toList())));
        spnCargo.setSelection(cargos.indexOf(cargos.stream().filter(c -> Objects.equals(c.getIdcargo(), profesor.getIdcargo())).collect(Collectors.toList()).get(0)));
        chkAsignar.setChecked(Objects.nonNull(profesor.getUser()));
        if(Objects.isNull(profesor.getUser())){
            spnUsuario.setVisibility(View.INVISIBLE);
        }else{
            spnUsuario.setSelection(usuarios.indexOf(usuarios.stream().filter(u -> u.getUser().equals(profesor.getUser())).collect(Collectors.toList()).get(0)));
        }
        chkAsignar.setOnCheckedChangeListener((compoundButton, b) -> {
            spnUsuario.setEnabled(b);
            spnUsuario.setVisibility(b ? View.VISIBLE : View.INVISIBLE);
        });
    }

    public void actualizar(View view) throws ClassNotFoundException {
        if(TextUtils.isEmpty(editNombre.getText())){
            Toast.makeText(this, "El nombre del profesor no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editApellido.getText())){
            Toast.makeText(this, "El apellido del profesor no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        Profesor prof = new Profesor();
        prof.setIdprofesor(profesor.getIdprofesor());
        prof.setNombre(editNombre.getText().toString());
        prof.setApellido(editApellido.getText().toString());
        prof.setIdcargo(cargos.stream().filter(c -> c.getCargo().equals(spnCargo.getSelectedItem())).collect(Collectors.toList()).get(0).getIdcargo());
        prof.setUser(chkAsignar.isChecked() ? (String) spnUsuario.getSelectedItem() : null);
        DatabaseOperations.abrirConexion();
        ProfesorRepository.actualizar(prof);
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("EncargadosActivity")));
        this.finish();
    }

    public void eliminar(View view) throws ClassNotFoundException {
        DatabaseOperations.abrirConexion();
        ProfesorRepository.eliminar(profesor.getIdprofesor());
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("EncargadosActivity")));
        finish();
    }


    @Override
    public void onBackPressed() {
        try {
            this.startActivity(new Intent(this, Rutas.getClase("EncargadosActivity")));
            this.finish();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}