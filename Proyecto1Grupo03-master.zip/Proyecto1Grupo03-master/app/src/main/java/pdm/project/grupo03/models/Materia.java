package pdm.project.grupo03.models;

import java.io.Serializable;

public class Materia implements Serializable {

    private String codmateria;
    private String nombre;
    private int unidadesv;
    private int obligatorio;
    private int numciclo;
    private String coordinador;

    public Materia() {
    }

    public Materia(String codmateria, String nombre, int obligatorio, int numciclo, String coordinador) {
        this.codmateria = codmateria;
        this.nombre = nombre;
        this.obligatorio = obligatorio;
        this.numciclo = numciclo;
        this.setUnidadesv(4);
        this.coordinador = coordinador;
    }

    public String getCodmateria() {
        return codmateria;
    }

    public void setCodmateria(String codmateria) {
        this.codmateria = codmateria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getUnidadesv() {
        return unidadesv;
    }

    public void setUnidadesv(int unidadesv) {
        this.unidadesv = unidadesv;
    }

    public int getObligatorio() {
        return obligatorio;
    }

    public void setObligatorio(int obligatorio) {
        this.obligatorio = obligatorio;
    }

    public int getNumciclo() {
        return numciclo;
    }

    public void setNumciclo(int numciclo) {
        this.numciclo = numciclo;
    }

    public String getCoordinador() {
        return coordinador;
    }

    public void setCoordinador(String coordinador) {
        this.coordinador = coordinador;
    }
}
