package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Cargo;
import pdm.project.grupo03.models.Dia;

public class CargoRepository {

    private static final String TABLA = "cargo";

    public static void guardar(Cargo cargo){
        ContentValues cv = new ContentValues();
        cv.put("idcargo", cargo.getIdcargo());
        cv.put("cargo", cargo.getCargo());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Cargo> consultar(String condiciones, String[] argumentos){
        List<Cargo> cargos = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return cargos;
        }
        while(!cursor.isAfterLast()){
            Cargo cargo = new Cargo();
            cargo.setIdcargo(cursor.getInt(0));
            cargo.setCargo(cursor.getString(1));
            cargos.add(cargo);
            cursor.moveToNext();
        }
        cursor.close();
        return cargos;
    }

}
