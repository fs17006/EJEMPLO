package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Objects;

import pdm.project.grupo03.adapters.ListViewAdapter;
import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.enums.ENUMS;
import pdm.project.grupo03.models.Ciclo;
import pdm.project.grupo03.models.Propuesta;
import pdm.project.grupo03.repositories.CicloRepository;
import pdm.project.grupo03.repositories.PropuestaRepository;
import pdm.project.grupo03.routing.Rutas;

public class PropuestasActivity extends AppCompatActivity {

    TextView txtCicloActual;
    ListView listView;
    Button btnAddPropuesta;
    ArrayList<Propuesta> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_propuestas);
        initPantalla();
        listView = findViewById(R.id.listView_propuestas);
        listView.setAdapter(new ListViewAdapter<>(this, R.layout.propuestas_list_item, items, ENUMS.TABLAS.PROPUESTA));
        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            if(!Objects.equals(Utils.loggedUser.getTipoUser(), 1)){
                editarPropuesta(items.get(i));
            }
        });
        btnAddPropuesta = findViewById(R.id.btn_add_propuesta);
        btnAddPropuesta.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.INVISIBLE : View.VISIBLE);
    }

    private void initPantalla(){
        txtCicloActual = findViewById(R.id.txt_ciclo_actual);
        DatabaseOperations.abrirConexion();
        Ciclo ciclo = CicloRepository.consultarCicloActual();
        items.addAll(PropuestaRepository.consultar(!Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? "user = ?" : null, !Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? new String[]{Utils.loggedUser.getUser()} : null ));
        DatabaseOperations.cerrarConexion();
        txtCicloActual.setText(ciclo.getIdciclo());
    }

    private void editarPropuesta(Propuesta propuesta) {
        try{
            Intent intent = new Intent(this, Rutas.getClase("PropuestasEditarActivity"));
            intent.putExtra("propuesta", propuesta);
            this.startActivity(intent);
            this.finish();
        }catch(ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
    }

    public void agregarPropuesta(View view) throws ClassNotFoundException {
        Intent intent = new Intent(this, Rutas.getClase("PropuestasAgregarActivity"));
        this.startActivity(intent);
        this.finish();
    }

}