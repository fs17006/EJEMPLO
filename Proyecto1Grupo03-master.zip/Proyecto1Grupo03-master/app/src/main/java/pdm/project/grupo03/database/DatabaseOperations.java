package pdm.project.grupo03.database;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import pdm.project.grupo03.enums.ENUMS;
import pdm.project.grupo03.models.Cargo;
import pdm.project.grupo03.models.Ciclo;
import pdm.project.grupo03.models.Dia;
import pdm.project.grupo03.models.Estado;
import pdm.project.grupo03.models.Horario;
import pdm.project.grupo03.models.Local;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Propuesta;
import pdm.project.grupo03.models.TipoActividad;
import pdm.project.grupo03.models.TipoUsuario;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.CargoRepository;
import pdm.project.grupo03.repositories.CicloRepository;
import pdm.project.grupo03.repositories.DiaRepository;
import pdm.project.grupo03.repositories.EstadoRepository;
import pdm.project.grupo03.repositories.HorarioRepository;
import pdm.project.grupo03.repositories.LocalRepository;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.PropuestaRepository;
import pdm.project.grupo03.repositories.TipoActividadRepository;
import pdm.project.grupo03.repositories.TipoUsuarioRepository;
import pdm.project.grupo03.repositories.UsuarioRepository;

public class DatabaseOperations {

    public static void abrirConexion(){
        DatabaseController.sqLiteDatabase = DatabaseController.databaseHelper.getWritableDatabase();
    }

    public static void cerrarConexion(){
        DatabaseController.databaseHelper.close();
    }

    public static void crearDatabase(SQLiteDatabase sqLiteDatabase){
        Log.i("INFO:", "inicializando base de datos...");
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.TIPOUSUARIO, "tipousuario"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.DIA, "dia"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.CARGO, "cargo"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.CICLO, "ciclo"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.ESTADO, "estado"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.HORARIO, "horario"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.TIPOACTIVIDAD, "tipoactividad"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.LOCAL, "local"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.USUARIO, "usuario"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.PROFESOR, "profesor"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.MATERIA, "materia"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.PROPUESTA, "propuesta"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.SOLICITUD, "solicitud"));
        sqLiteDatabase.execSQL(crearTabla(ENUMS.TABLAS.SOLICITUDDETA, "solicituddeta"));
        Log.i("INFO:", "Finalizando inicialización base de datos...");
    }

    public static void inicializarDatabase(){
        abrirConexion();
        borrarData();

        initDias();
        initHorarios();
        initEstados();
        initCargos();
        initCiclos();
        initTiposActividad();
        initLocales();
        initTipoUsuario();
        initUsuarios();
        initProfesores();
        initMaterias();
        initPropuestas();
        initSolicitudes();
        initSolicitudesDeta();

        cerrarConexion();
    }

    private static void borrarData(){
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("tipousuario"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("dia"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("cargo"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("ciclo"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("estado"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("horario"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("tipoactividad"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("local"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("usuario"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("profesor"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("materia"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("propuesta"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("solicitud"));
        DatabaseController.sqLiteDatabase.execSQL(borrarTabla("solicituddeta"));
    }

    private static String borrarTabla(String nombreTabla){
        return new StringBuilder().append("DELETE FROM ").append(nombreTabla).append(";").toString();
    }

    private static String crearTabla(ENUMS.TABLAS tabla, String nombreTabla){
        StringBuilder sqlStatement = new StringBuilder();
        return sqlStatement
                    .append("CREATE TABLE ").append(nombreTabla)
                    .append(" ( ")
                    .append(getDefinicionTabla(tabla))
                    .append(" );").toString();
    }

    private static String getDefinicionTabla(ENUMS.TABLAS tabla){
        StringBuilder sqlStatement = new StringBuilder();
        switch(tabla){
            case USUARIO:{
                return sqlStatement
                        .append("user VARCHAR(15) PRIMARY KEY, ")
                        .append("pass VARCHAR(25) NOT NULL, ")
                        .append("tipouser INTEGER NOT NULL").toString();
            }
            case MATERIA:{
                return sqlStatement
                        .append("codmateria VARCHAR(7) PRIMARY KEY, ")
                        .append("nombre VARCHAR(60) NOT NULL, ")
                        .append("unidadesv INTEGER NOT NULL, ")
                        .append("obligatorio BOOLEAN NOT NULL, ")
                        .append("numciclo INTEGER NOT NULL, ")
                        .append("coordinador VARCHAR(10) ").toString();
            }
            case HORARIO:{
                return sqlStatement
                        .append("idhora INTEGER PRIMARY KEY, ")
                        .append("hora VARCHAR(60) NOT NULL ").toString();
            }
            case CARGO:{
                return sqlStatement
                        .append("idcargo INTEGER PRIMARY KEY, ")
                        .append("cargo VARCHAR(20) NOT NULL ").toString();
            }
            case DIA: {
                return sqlStatement
                        .append("iddia INTEGER PRIMARY KEY, ")
                        .append("dia VARCHAR(10) NOT NULL ").toString();
            }
            case CICLO: {
                return sqlStatement
                        .append("idciclo VARCHAR(20) PRIMARY KEY, ")
                        .append("numciclo INTEGER NOT NULL, ")
                        .append("anio INTEGER NOT NULL, ")
                        .append("actual INTEGER").toString();
            }
            case ESTADO: {
                return sqlStatement
                        .append("idestado INTEGER PRIMARY KEY, ")
                        .append("estado VARCHAR(10) NOT NULL ").toString();
            }
            case LOCAL: {
                return sqlStatement
                        .append("idlocal VARCHAR(10) PRIMARY KEY, ")
                        .append("idencargado VARCHAR(20) ").toString();
            }
            case PROFESOR:{
                return sqlStatement
                        .append("idprofesor VARCHAR(10) PRIMARY KEY, ")
                        .append("nombre VARCHAR(30) NOT NULL, ")
                        .append("apellido VARCHAR(30), ")
                        .append("idcargo INTEGER NOT NULL, ")
                        .append("user VARCHAR(15) ").toString();
            }
            case PROPUESTA: {
                return sqlStatement
                        .append("idpropuesta INTEGER PRIMARY KEY, ")
                        .append("idciclo VARCHAR(20) NOT NULL, ")
                        .append("codmateria VARCHAR(10) NOT NULL, ")
                        .append("idlocal VARCHAR(10) NOT NULL, ")
                        .append("idtipoactividad INTEGER NOT NULL, ")
                        .append("iddia INTEGER NOT NULL, ")
                        .append("idhora INTEGER NOT NULL, ")
                        .append("grupo INTEGER NOT NULL, ")
                        .append("user VARCHAR(30) NOT NULL, ")
                        .append("idestado INTEGER NOT NULL").toString();
            }
            case SOLICITUD: {
                return sqlStatement
                        .append("idsolicitud INTEGER PRIMARY KEY, ")
                        .append("idciclo INTEGER NOT NULL, ")
                        .append("idlocal INTEGER NOT NULL, ")
                        .append("idestado INTEGER NOT NULL, ")
                        .append("enviado INTEGER").toString();
            }
            case SOLICITUDDETA: {
                return sqlStatement
                        .append("idsolicitud INTEGER, ")
                        .append("idpropuesta INTEGER, ")
                        .append("PRIMARY KEY(idsolicitud, idpropuesta)").toString();
            }
            case TIPOACTIVIDAD: {
                return sqlStatement
                        .append("idtipoactividad INTEGER PRIMARY KEY, ")
                        .append("tipoactividad VARCHAR(20) NOT NULL ").toString();
            }
            case TIPOUSUARIO: {
                return sqlStatement
                        .append("idtipousuario INTEGER PRIMARY KEY, ")
                        .append("tipousuario VARCHAR(10) NOT NULL ").toString();
            }
            default: {
                return sqlStatement.toString();
            }
        }
    }



    private static void initEstados(){
        EstadoRepository.guardar(new Estado(1, "Generado"));
        EstadoRepository.guardar(new Estado(2, "Enviado"));
        EstadoRepository.guardar(new Estado(3, "Aceptado"));
        EstadoRepository.guardar(new Estado(4, "Rechazado"));
    }

    private static void initCargos(){
        CargoRepository.guardar(new Cargo(2, "Coordinador"));
        CargoRepository.guardar(new Cargo(3, "Encargado"));
    }

    private static void initCiclos(){
        CicloRepository.guardar(new Ciclo("Ciclo I - 2023", 1, 2023, 1));
    }

    private static void initDias(){
        DiaRepository.guardar(new Dia(1, "Lunes"));
        DiaRepository.guardar(new Dia(2, "Martes"));
        DiaRepository.guardar(new Dia(3, "Miercoles"));
        DiaRepository.guardar(new Dia(4, "Jueves"));
        DiaRepository.guardar(new Dia(5, "Viernes"));
    }

    private static void initHorarios(){
        HorarioRepository.guardar(new Horario(1, "6:20 AM - 8:00 AM"));
        HorarioRepository.guardar(new Horario(2, "8:05 AM - 9:45 AM"));
        HorarioRepository.guardar(new Horario(3, "9:50 AM - 11:30 AM"));
        HorarioRepository.guardar(new Horario(4, "11:35 AM - 1:15 PM"));
        HorarioRepository.guardar(new Horario(5, "1:20 PM - 3:00 PM"));
        HorarioRepository.guardar(new Horario(6, "3:05 PM - 4:45 PM"));
        HorarioRepository.guardar(new Horario(7, "4:50 PM - 6:30 PM"));
        HorarioRepository.guardar(new Horario(8, "6:35 PM - 8:15 PM"));
    }

    private static void initTiposActividad(){
        TipoActividadRepository.guardar(new TipoActividad(1, "Teórico"));
        TipoActividadRepository.guardar(new TipoActividad(2, "Laboratorio"));
        TipoActividadRepository.guardar(new TipoActividad(3, "Foro"));
        TipoActividadRepository.guardar(new TipoActividad(4, "Parcial"));
        TipoActividadRepository.guardar(new TipoActividad(5, "Discusión"));
    }

    private static void initLocales(){
        LocalRepository.guardar(new Local("B11", "JJ2020"));
        LocalRepository.guardar(new Local("B21", "JJ2020"));
        LocalRepository.guardar(new Local("B22", "JJ2020"));
        LocalRepository.guardar(new Local("B31", "GC2019"));
        LocalRepository.guardar(new Local("B32", "GC2019"));
        LocalRepository.guardar(new Local("B33", "GC2019"));
        LocalRepository.guardar(new Local("C11", "JZ2018"));
        LocalRepository.guardar(new Local("C21", "JZ2018"));
        LocalRepository.guardar(new Local("C22", "JZ2018"));
        LocalRepository.guardar(new Local("C31", "JZ2018"));
        LocalRepository.guardar(new Local("C32", "JZ2018"));
        LocalRepository.guardar(new Local("D11", "RM2017"));
        LocalRepository.guardar(new Local("D21", "RM2017"));
        LocalRepository.guardar(new Local("D22", "RM2017"));
        LocalRepository.guardar(new Local("D31", "RM2017"));
        LocalRepository.guardar(new Local("D32", "RM2017"));
        LocalRepository.guardar(new Local("LCOMP01", "JI2021"));
        LocalRepository.guardar(new Local("LCOMP02", "JI2021"));
        LocalRepository.guardar(new Local("LCOMP03", "JI2021"));
        LocalRepository.guardar(new Local("LCOMP04", "JI2021"));
        LocalRepository.guardar(new Local("LCOMP05", "JI2021"));
    }

    private static void initTipoUsuario(){
        TipoUsuarioRepository.guardar(new TipoUsuario(1, "Administrador"));
        TipoUsuarioRepository.guardar(new TipoUsuario(2, "Coordinador"));
        TipoUsuarioRepository.guardar(new TipoUsuario(3, "Encargado"));
    }

    private static void initUsuarios(){
        UsuarioRepository.guardar(new Usuario("admin", "admin", 1));
        UsuarioRepository.guardar(new Usuario("bladimir", "bladimir", 2));
        UsuarioRepository.guardar(new Usuario("warner", "warner", 2));
        UsuarioRepository.guardar(new Usuario("carlos", "carlos", 2));
        UsuarioRepository.guardar(new Usuario("mario", "mario", 2));
        UsuarioRepository.guardar(new Usuario("cesar", "cesar", 2));

        UsuarioRepository.guardar(new Usuario("jorge", "jorge", 3));
        UsuarioRepository.guardar(new Usuario("jacome", "jacome", 3));
        UsuarioRepository.guardar(new Usuario("gabriel", "gabriel", 3));
        UsuarioRepository.guardar(new Usuario("julio", "julio", 3));
        UsuarioRepository.guardar(new Usuario("rene", "rene", 3));
    }

    private static void initProfesores(){
        ProfesorRepository.guardar(new Profesor("BD2021", "Bladimir", "Díaz", 2, "bladimir"));
        ProfesorRepository.guardar(new Profesor("WG2020", "Warner", "Gilmar", 2, "warner"));
        ProfesorRepository.guardar(new Profesor("CT2019", "Carlos", "Turcios", 2, "carlos"));
        ProfesorRepository.guardar(new Profesor("MH2018", "Mario", "Fernández", 2, "mario"));
        ProfesorRepository.guardar(new Profesor("CG2017", "Cesar", "González", 2, "cesar"));

        ProfesorRepository.guardar(new Profesor("JI2021", "Jorge", "Iraheta", 3, "jorge"));
        ProfesorRepository.guardar(new Profesor("JJ2020", "José", "Jacome", 3, "jacome"));
        ProfesorRepository.guardar(new Profesor("GC2019", "Gabriel", "Catacho", 3, null));
        ProfesorRepository.guardar(new Profesor("JZ2018", "Julio", "Zepeda", 3, "julio"));
        ProfesorRepository.guardar(new Profesor("RM2017", "René", "Monge", 3, "rene"));
    }

    private static void initMaterias(){
        MateriaRepository.guardar(new Materia("IAI115", "Introducción a la Informática", 1, 1, "BD2021"));
        MateriaRepository.guardar(new Materia("MAT115", "Matemáticas I", 1, 1, "WG2020"));
        MateriaRepository.guardar(new Materia("MTE115", "Métodos Experimentales", 1, 1, "CT2019"));
        MateriaRepository.guardar(new Materia("FDE115", "Fundamentos de Economía", 1, 2, "MH2018"));
        MateriaRepository.guardar(new Materia("PDM115", "Programación para Dispositivos Móviles", 1, 8, "CG2017"));
    }

    private static void initPropuestas(){
        PropuestaRepository.guardar(new Propuesta(1, "Ciclo I - 2023", "PDM115", "LCOMP01", 2, 2, 2, 1, "cesar", 2));
        PropuestaRepository.guardar(new Propuesta(2, "Ciclo I - 2023", "IAI115", "LCOMP01", 2, 2, 2, 1, "bladimir", 2));
    }

    private static void initSolicitudes(){

    }

    private static void initSolicitudesDeta(){

    }

}
