package pdm.project.grupo03.models;

public class Dia {

    private int iddia;
    private String dia;

    public Dia() {
    }

    public Dia(int iddia, String dia) {
        this.iddia = iddia;
        this.dia = dia;
    }

    public int getIddia() {
        return iddia;
    }

    public void setIddia(int iddia) {
        this.iddia = iddia;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }
}
