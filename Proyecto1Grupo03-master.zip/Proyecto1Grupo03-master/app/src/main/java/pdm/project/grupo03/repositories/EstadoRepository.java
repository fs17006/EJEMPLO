package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Dia;
import pdm.project.grupo03.models.Estado;

public class EstadoRepository {

    private static final String TABLA = "estado";

    public static void guardar(Estado estado){
        ContentValues cv = new ContentValues();
        cv.put("idestado", estado.getIdestado());
        cv.put("estado", estado.getEstado());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Estado> consultar(String condiciones, String[] argumentos){
        List<Estado> estados = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return estados;
        }
        while(!cursor.isAfterLast()){
            Estado estado = new Estado();
            estado.setIdestado(cursor.getInt(0));
            estado.setEstado(cursor.getString(1));
            estados.add(estado);
            cursor.moveToNext();
        }
        cursor.close();
        return estados;
    }
}
