package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;

import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Cargo;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.CargoRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.UsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class EncargadosAgregarActivity extends AppCompatActivity {

    EditText editNombre;
    EditText editApellido;
    Spinner spnUsuario;
    Spinner spnCargo;
    CheckBox chkAsignar;

    List<Cargo> cargos;
    List<Usuario> usuarios;
    List<Profesor> profesores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encargados_agregar);
        editNombre = findViewById(R.id.edit_nombre_add_encargados);
        editApellido = findViewById(R.id.edit_apellido_add_encargados);
        spnCargo = findViewById(R.id.spn_cargo_add_encargados);
        spnUsuario = findViewById(R.id.spn_usuario_add_encargados);
        chkAsignar = findViewById(R.id.chk_asignar_cuenta);
        DatabaseOperations.abrirConexion();
        cargos = CargoRepository.consultar(null, null);
        profesores = ProfesorRepository.consultar("user is not null", null);
        StringBuilder list = new StringBuilder("(");
        profesores.forEach(p -> list.append("'").append(p.getUser()).append("'").append(","));
        usuarios = UsuarioRepository.consultar("user not in " + list.substring(0, list.length() - 1) + ",'admin')" , null);
        DatabaseOperations.cerrarConexion();
        spnUsuario.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, usuarios.stream().map(Usuario::getUser).collect(Collectors.toList())));
        spnCargo.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, cargos.stream().map(Cargo::getCargo).collect(Collectors.toList())));
        chkAsignar.setChecked(true);
        chkAsignar.setOnCheckedChangeListener((compoundButton, b) -> {
            spnUsuario.setEnabled(b);
            spnUsuario.setVisibility(b ? View.VISIBLE : View.INVISIBLE);
        });
    }

    public void guardar(View view) throws ClassNotFoundException {
        if(TextUtils.isEmpty(editNombre.getText())){
            Toast.makeText(this, "El nombre del profesor no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editApellido.getText())){
            Toast.makeText(this, "El apellido del profesor no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        Profesor profesor = new Profesor();
        profesor.setNombre(editNombre.getText().toString());
        profesor.setApellido(editApellido.getText().toString());
        profesor.setIdprofesor(String.valueOf(profesor.getNombre().charAt(0)).toUpperCase() + String.valueOf(profesor.getApellido().charAt(0)).toUpperCase() + Calendar.getInstance().get(Calendar.YEAR));
        profesor.setUser(chkAsignar.isChecked() ? (String) spnUsuario.getSelectedItem() : null);
        profesor.setIdcargo(cargos.stream().filter(c -> c.getCargo().equals(spnCargo.getSelectedItem())).collect(Collectors.toList()).get(0).getIdcargo());
        DatabaseOperations.abrirConexion();
        ProfesorRepository.guardar(profesor);
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("EncargadosActivity")));
        this.finish();
    }

    @Override
    public void onBackPressed() {
        try {
            this.startActivity(new Intent(this, Rutas.getClase("EncargadosActivity")));
            this.finish();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

}