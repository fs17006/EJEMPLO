package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;
import java.util.stream.Collectors;

import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.TipoUsuario;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.TipoUsuarioRepository;
import pdm.project.grupo03.repositories.UsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class UsuarioAgregarActivity extends AppCompatActivity {

    EditText user;
    EditText pass;
    Spinner tipoUser;

    List<TipoUsuario> tiposUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario_agregar);
        user = findViewById(R.id.txt_user);
        pass = findViewById(R.id.txt_pass);
        tipoUser = findViewById(R.id.spn_tipo_user);
        DatabaseOperations.abrirConexion();
        tiposUsuario = TipoUsuarioRepository.consultar();
        DatabaseOperations.cerrarConexion();
        tipoUser.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, tiposUsuario.stream().map(TipoUsuario::getTipoUsuario).collect(Collectors.toList())));
    }

    public void guardarNuevoUsuario(View view) throws ClassNotFoundException {
        if(TextUtils.isEmpty(user.getText())){
            Toast.makeText(this, "El usuario no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(pass.getText())){
            Toast.makeText(this, "La contraseña no puede estar vacía", Toast.LENGTH_SHORT).show();
            return;
        }
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setUser(user.getText().toString());
        nuevoUsuario.setPass(pass.getText().toString());
        nuevoUsuario.setTipoUser(tiposUsuario.stream().filter(tu -> tu.getTipoUsuario().equals(tipoUser.getSelectedItem())).collect(Collectors.toList()).get(0).getIdTipoUsuario());
        DatabaseOperations.abrirConexion();
        UsuarioRepository.guardar(nuevoUsuario);
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("UsuariosActivity")));
        this.finish();
    }

    @Override
    public void onBackPressed() {
        try {
            this.startActivity(new Intent(this, Rutas.getClase("UsuariosActivity")));
            this.finish();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}