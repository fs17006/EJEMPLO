package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Usuario;

public class UsuarioRepository {

    private static final String TABLA = "usuario";

    public static void guardar(Usuario usuario){
        ContentValues cv = new ContentValues();
        cv.put("user", usuario.getUser());
        cv.put("pass", usuario.getPass());
        cv.put("tipouser", usuario.getTipoUser());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Usuario> consultar(String condiciones, String[] argumentos){
        List<Usuario> usuarios = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return usuarios;
        }
        while(!cursor.isAfterLast()){
            Usuario user = new Usuario();
            user.setUser(cursor.getString(0));
            user.setPass(cursor.getString(1));
            user.setTipoUser(cursor.getInt(2));
            usuarios.add(user);
            cursor.moveToNext();
        }
        cursor.close();
        return usuarios;
    }

    public static Usuario consultar(String usuario){
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, new String[]{"user", "pass", "tipouser"}, "user = ?", new String[]{usuario}, null, null, null);
        Usuario user = null;
        if(cursor.moveToFirst()){
            user = new Usuario();
            user.setUser(cursor.getString(0));
            user.setPass(cursor.getString(1));
            user.setTipoUser(cursor.getInt(2));
        }
        cursor.close();
        return user;
    }

    public static void actualizar(Usuario usuario){
        Usuario user = consultar(usuario.getUser());
        if(Objects.nonNull(user)){
            ContentValues cv = new ContentValues();
            cv.put("tipouser", usuario.getTipoUser());
            DatabaseController.sqLiteDatabase.update(TABLA, cv, "user = ?", new String[]{usuario.getUser()});
        }
    }

    public static void eliminar(Usuario usuario){
        Usuario user = consultar(usuario.getUser());
        if(Objects.nonNull(user)){
            DatabaseController.sqLiteDatabase.delete(TABLA, "user = ?", new String[]{usuario.getUser()});
        }
    }

}
