package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.TipoUsuario;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.TipoUsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class MateriasAgregarActivity extends AppCompatActivity {

    EditText editCodmateria;
    EditText editNombreMateria;
    EditText editCicloMateria;
    EditText editUvMateria;
    Switch swtObligatoria;
    Spinner spnCoordinador;
    List<Profesor> profesores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materias_agregar);
        editCodmateria = findViewById(R.id.edit_codmateria);
        editNombreMateria = findViewById(R.id.edit_nombre_materia);
        editCicloMateria = findViewById(R.id.edit_ciclo_materia);
        editUvMateria = findViewById(R.id.edit_uv_materia);
        editUvMateria.setText("4");
        swtObligatoria = findViewById(R.id.swt_es_obligatoria);
        spnCoordinador = findViewById(R.id.spn_coordinador_add_materia);
        DatabaseOperations.abrirConexion();
        profesores = ProfesorRepository.consultar("idcargo = ?", new String[]{ String.valueOf(2) });
        DatabaseOperations.cerrarConexion();
        spnCoordinador.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, profesores.stream().map(p -> p.getNombre() + " " + p.getApellido()).collect(Collectors.toList())));

    }

    public void guardarNuevaMateria(View view) throws ClassNotFoundException {
        if(TextUtils.isEmpty(editCodmateria.getText())){
            Toast.makeText(this, "El código de la materia no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editNombreMateria.getText())){
            Toast.makeText(this, "El nombre de la materia no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editUvMateria.getText())){
            Toast.makeText(this, "La materia debe tener unidades valorativas", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editCicloMateria.getText())){
            Toast.makeText(this, "El ciclo al que pertenece la materia no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        Materia nuevaMateria = new Materia();
        nuevaMateria.setCodmateria(editCodmateria.getText().toString());
        nuevaMateria.setNombre(editNombreMateria.getText().toString());
        nuevaMateria.setNumciclo(Integer.parseInt(editCicloMateria.getText().toString()));
        nuevaMateria.setUnidadesv(Integer.parseInt(editUvMateria.getText().toString()));
        nuevaMateria.setObligatorio(swtObligatoria.isChecked() ? 1 : 0);
        nuevaMateria.setCoordinador(profesores.stream().filter(p -> (p.getNombre() + " " + p.getApellido()).equals(spnCoordinador.getSelectedItem())).collect(Collectors.toList()).get(0).getIdprofesor());
        DatabaseOperations.abrirConexion();
        MateriaRepository.guardar(nuevaMateria);
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("MateriasActivity")));
        this.finish();
    }

    @Override
    public void onBackPressed() {
        try {
            this.startActivity(new Intent(this, Rutas.getClase("MateriasActivity")));
            this.finish();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}