package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Ciclo;
import pdm.project.grupo03.models.Materia;

public class CicloRepository {

    private static final String TABLA = "ciclo";

    public static void guardar(Ciclo ciclo){
        ContentValues cv = new ContentValues();
        cv.put("idciclo", ciclo.getIdciclo());
        cv.put("numciclo", ciclo.getNumciclo());
        cv.put("anio", ciclo.getAnio());
        cv.put("actual", ciclo.getActual());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static Ciclo consultarCicloActual(){
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, "actual = ?", new String[]{String.valueOf(1)}, null, null, null);
        Ciclo ciclo = null;
        if(cursor.moveToFirst()){
            ciclo = new Ciclo();
            ciclo.setIdciclo(cursor.getString(0));
            ciclo.setNumciclo(cursor.getInt(1));
            ciclo.setAnio(cursor.getInt(2));
            ciclo.setActual(cursor.getInt(3));
        }
        cursor.close();
        return ciclo;
    }
}
