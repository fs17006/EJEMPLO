package pdm.project.grupo03.models;

public class Solicitud {

    private int idsolicitud;
    private String idciclo;
    private String idlocal;
    private int idestado;
    private int enviado;

    public Solicitud() {
    }

    public Solicitud(int idsolicitud, String idciclo, String idlocal, int idestado, int enviado) {
        this.idsolicitud = idsolicitud;
        this.idciclo = idciclo;
        this.idlocal = idlocal;
        this.idestado = idestado;
        this.enviado = enviado;
    }

    public int getIdsolicitud() {
        return idsolicitud;
    }

    public void setIdsolicitud(int idsolicitud) {
        this.idsolicitud = idsolicitud;
    }

    public String getIdciclo() {
        return idciclo;
    }

    public void setIdciclo(String idciclo) {
        this.idciclo = idciclo;
    }

    public String getIdlocal() {
        return idlocal;
    }

    public void setIdlocal(String idlocal) {
        this.idlocal = idlocal;
    }

    public int getIdestado() {
        return idestado;
    }

    public void setIdestado(int idestado) {
        this.idestado = idestado;
    }

    public int getEnviado() {
        return enviado;
    }

    public void setEnviado(int enviado) {
        this.enviado = enviado;
    }
}
