package pdm.project.grupo03.constants;

import java.util.Objects;

import pdm.project.grupo03.models.Usuario;

public class Utils {

    public static Usuario loggedUser = null;
    public static String getTipoUser(int tipoUser){
        return Objects.equals(tipoUser, 10) ? "Administrador" : Objects.equals(tipoUser, 20) ? "Docente" : "Encargado";
    }

    public static int getTipoUser(String tipoUser){
        return Objects.equals(tipoUser, "Administrador") ? 10 : Objects.equals(tipoUser, "Docente") ? 20 : 30;
    }

}
