package pdm.project.grupo03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import pdm.project.grupo03.constants.Utils;
import pdm.project.grupo03.database.DatabaseOperations;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Profesor;
import pdm.project.grupo03.models.Usuario;
import pdm.project.grupo03.repositories.MateriaRepository;
import pdm.project.grupo03.repositories.ProfesorRepository;
import pdm.project.grupo03.repositories.UsuarioRepository;
import pdm.project.grupo03.routing.Rutas;

public class MateriasEditarActivity extends AppCompatActivity {

    Materia materia;
    EditText editCodmateria;
    EditText editNombreMateria;
    EditText editCicloMateria;
    EditText editUvMateria;
    Switch swtObligatoria;
    Spinner spnCoordinador;
    Button btnActualizarMateria;
    Button btnEliminarMateria;
    List<Profesor> profesores;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materias_editar);
        materia = (Materia) getIntent().getSerializableExtra("materia");
        editCodmateria = findViewById(R.id.edit_codmateria);
        editNombreMateria = findViewById(R.id.edit_nombre_materia);
        editCicloMateria = findViewById(R.id.edit_ciclo_materia);
        editUvMateria = findViewById(R.id.edit_uv_materia);
        swtObligatoria = findViewById(R.id.swt_es_obligatoria);
        spnCoordinador = findViewById(R.id.spn_coordinador_edit_materia);
        btnActualizarMateria = findViewById(R.id.btn_actualizar_materia);
        btnEliminarMateria = findViewById(R.id.btn_eliminar_materia);
        DatabaseOperations.abrirConexion();
        profesores = ProfesorRepository.consultar("idcargo = ?", new String[]{ String.valueOf(2) });
        DatabaseOperations.cerrarConexion();
        btnActualizarMateria.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.VISIBLE : View.INVISIBLE);
        btnEliminarMateria.setVisibility(Objects.equals(Utils.loggedUser.getTipoUser(), 1) ? View.VISIBLE : View.INVISIBLE);
        spnCoordinador.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, profesores.stream().map(p -> p.getNombre() + " " + p.getApellido()).collect(Collectors.toList())));
        editCodmateria.setText(materia.getCodmateria());
        editNombreMateria.setText(materia.getNombre());
        editUvMateria.setText(String.valueOf(materia.getUnidadesv()));
        editCicloMateria.setText(String.valueOf(materia.getNumciclo()));
        swtObligatoria.setChecked(Objects.equals(materia.getObligatorio(), 1));
        spnCoordinador.setSelection(profesores.stream().anyMatch(pf -> pf.getIdprofesor().equals(materia.getCoordinador())) ?
                profesores.indexOf(profesores.stream().filter(pf -> pf.getIdprofesor().equals(materia.getCoordinador())).collect(Collectors.toList()).get(0)) : 0);
    }

    public void actualizarMateria(View view) throws ClassNotFoundException {
        if(TextUtils.isEmpty(editCodmateria.getText())){
            Toast.makeText(this, "El código de la materia no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editNombreMateria.getText())){
            Toast.makeText(this, "El nombre de la materia no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editUvMateria.getText())){
            Toast.makeText(this, "La materia debe tener unidades valorativas", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(editCicloMateria.getText())){
            Toast.makeText(this, "El ciclo al que pertenece la materia no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }
        Materia mat = new Materia();
        mat.setCodmateria(editCodmateria.getText().toString());
        mat.setNombre(editNombreMateria.getText().toString());
        mat.setNumciclo(Integer.parseInt(editCicloMateria.getText().toString()));
        mat.setUnidadesv(Integer.parseInt(editUvMateria.getText().toString()));
        mat.setObligatorio(swtObligatoria.isChecked() ? 1 : 0);
        mat.setCoordinador(profesores.stream().filter(p -> (p.getNombre() + " " + p.getApellido()).equals(spnCoordinador.getSelectedItem())).collect(Collectors.toList()).get(0).getIdprofesor());
        DatabaseOperations.abrirConexion();
        MateriaRepository.actualizar(mat);
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("MateriasActivity")));
        this.finish();
    }

    public void eliminarMateria(View view) throws ClassNotFoundException {
        DatabaseOperations.abrirConexion();
        MateriaRepository.eliminar(editCodmateria.getText().toString());
        DatabaseOperations.cerrarConexion();
        this.startActivity(new Intent(this, Rutas.getClase("MateriasActivity")));
        finish();
    }

    @Override
    public void onBackPressed() {
        try {
            this.startActivity(new Intent(this, Rutas.getClase("MateriasActivity")));
            this.finish();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}