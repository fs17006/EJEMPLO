package pdm.project.grupo03.models;

import java.io.Serializable;

public class Usuario implements Serializable {

    private String user;
    private String pass;
    private int tipoUser;

    public Usuario() {
    }

    public Usuario(String user, String pass, int tipoUser) {
        this.user = user;
        this.pass = pass;
        this.tipoUser = tipoUser;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public int getTipoUser() {
        return tipoUser;
    }

    public void setTipoUser(int tipoUser) {
        this.tipoUser = tipoUser;
    }
}
