package pdm.project.grupo03.models;

public class Ciclo {

    private String idciclo;
    private int numciclo;
    private int anio;
    private int actual;

    public Ciclo() {
    }

    public Ciclo(String idciclo, int numciclo, int anio, int actual) {
        this.idciclo = idciclo;
        this.numciclo = numciclo;
        this.anio = anio;
        this.actual = actual;
    }

    public String getIdciclo() {
        return idciclo;
    }

    public void setIdciclo(String idciclo) {
        this.idciclo = idciclo;
    }

    public int getNumciclo() {
        return numciclo;
    }

    public void setNumciclo(int numciclo) {
        this.numciclo = numciclo;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public int getActual() {
        return actual;
    }

    public void setActual(int actual) {
        this.actual = actual;
    }
}
