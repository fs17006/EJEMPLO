package pdm.project.grupo03.enums;

public class ENUMS {

    public enum TABLAS{
        USUARIO,
        TIPOUSUARIO,
        MATERIA,
        PROFESOR,
        HORARIO,
        DIA,
        LOCAL,
        PROPUESTA,
        ESTADO,
        TIPOACTIVIDAD,
        CICLO,
        CARGO,
        SOLICITUD,
        SOLICITUDDETA
    }

}
