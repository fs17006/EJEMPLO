package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Profesor;

public class ProfesorRepository {

    private static final String TABLA = "profesor";

    public static void guardar(Profesor profesor){
        ContentValues cv = new ContentValues();
        cv.put("idprofesor", profesor.getIdprofesor());
        cv.put("nombre", profesor.getNombre());
        cv.put("apellido", profesor.getApellido());
        cv.put("idcargo", profesor.getIdcargo());
        cv.put("user", profesor.getUser());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Profesor> consultar(String condiciones, String[] argumentos){
        List<Profesor> profesores = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return profesores;
        }
        while(!cursor.isAfterLast()){
            Profesor profesor = new Profesor();
            profesor.setIdprofesor(cursor.getString(0));
            profesor.setNombre(cursor.getString(1));
            profesor.setApellido(cursor.getString(2));
            profesor.setIdcargo(cursor.getInt(3));
            profesor.setUser(cursor.getString(4));
            profesores.add(profesor);
            cursor.moveToNext();
        }
        cursor.close();
        return profesores;
    }

    public static void actualizar(Profesor profesor){
        Profesor prof = consultar("idprofesor = ?", new String[]{ profesor.getIdprofesor() }).get(0);
        if(Objects.nonNull(prof)){
            ContentValues cv = new ContentValues();
            cv.put("nombre", profesor.getNombre());
            cv.put("apellido", profesor.getApellido());
            cv.put("idcargo", profesor.getIdcargo());
            cv.put("user", profesor.getUser());
            DatabaseController.sqLiteDatabase.update(TABLA, cv, "idprofesor = ?", new String[]{ profesor.getIdprofesor() });
        }
    }

    public static void eliminar(String idprofesor){
        Profesor profesor = consultar("idprofesor = ?", new String[]{ idprofesor }).get(0);
        if(Objects.nonNull(profesor)){
            DatabaseController.sqLiteDatabase.delete(TABLA, "idprofesor = ?", new String[]{profesor.getIdprofesor()});
        }
    }

}
