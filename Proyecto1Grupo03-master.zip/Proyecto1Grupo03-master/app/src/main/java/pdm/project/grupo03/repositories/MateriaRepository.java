package pdm.project.grupo03.repositories;

import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import pdm.project.grupo03.database.DatabaseController;
import pdm.project.grupo03.models.Materia;
import pdm.project.grupo03.models.Usuario;

public class MateriaRepository {

    private static final String TABLA = "materia";

    public static void guardar(Materia materia){
        ContentValues cv = new ContentValues();
        cv.put("codmateria", materia.getCodmateria());
        cv.put("nombre", materia.getNombre());
        cv.put("unidadesv", materia.getUnidadesv());
        cv.put("obligatorio", materia.getObligatorio());
        cv.put("numciclo", materia.getNumciclo());
        cv.put("coordinador", materia.getCoordinador());
        DatabaseController.sqLiteDatabase.insert(TABLA, null, cv);
    }

    public static List<Materia> consultar(String condiciones, String[] argumentos){
        List<Materia> materias = new ArrayList<>();
        Cursor cursor = DatabaseController.sqLiteDatabase.query(TABLA, null, condiciones, argumentos, null, null, null);
        if(!cursor.moveToFirst()){
            return materias;
        }
        while(!cursor.isAfterLast()){
            Materia materia = new Materia();
            materia.setCodmateria(cursor.getString(0));
            materia.setNombre(cursor.getString(1));
            materia.setUnidadesv(cursor.getInt(2));
            materia.setObligatorio(cursor.getInt(3));
            materia.setNumciclo(cursor.getInt(4));
            materia.setCoordinador(cursor.getString(5));
            materias.add(materia);
            cursor.moveToNext();
        }
        cursor.close();
        return materias;
    }

    public static void actualizar(Materia materia){
        Materia mat = consultar("codmateria = ?", new String[]{ materia.getCodmateria() }).get(0);
        if(Objects.nonNull(mat)){
            ContentValues cv = new ContentValues();
            cv.put("nombre", materia.getNombre());
            cv.put("unidadesv", materia.getUnidadesv());
            cv.put("obligatorio", materia.getObligatorio());
            cv.put("numciclo", materia.getNumciclo());
            cv.put("coordinador", materia.getCoordinador());
            DatabaseController.sqLiteDatabase.update(TABLA, cv, "codmateria = ?", new String[]{materia.getCodmateria()});
        }
    }

    public static void eliminar(String codmateria){
        Materia materia = consultar("codmateria = ?", new String[]{ codmateria }).get(0);
        if(Objects.nonNull(materia)){
            DatabaseController.sqLiteDatabase.delete(TABLA, "codmateria = ?", new String[]{materia.getCodmateria()});
        }
    }

}
